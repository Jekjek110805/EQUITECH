<?php
session_start();
require_once __DIR__ . '/utils.php';

// If remember cookie present, remove token server-side and clear cookie
if (!empty($_COOKIE['remember_me'])) {
    clear_remember_cookie();
} else {
    // Ensure cookie cleared even if $_COOKIE was not present (defensive)
    $options = get_cookie_options(time() - 3600);
    setcookie('remember_me', '', $options);
}

// Clear session data (including any old_username flash) and session cookie
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

// Prevent caching of authenticated pages
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Redirect to login form (index.php)
header('Location: index.php');
exit;