<?php
function get_users(): {

return [
    
    r


]
}


?>