<?php
session_start();
// If already logged in, go to dashboard
if (isset($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

// Grab flash data (old username and error), then clear them so they don't persist
$old_username = $_SESSION['old_username'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['old_username'], $_SESSION['error']);

// Should we preserve the username in the form? Only preserve when there's an error (failed login).
$preserve_username = $old_username !== '';  
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <style>
    /* 1. Global Reset and Typography */
    :root {
      --primary-color: #007bff;
      --primary-dark: #0056b3;
      --background-light: #224dc2ff;
      --card-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      --border-radius: 8px;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
      background-color: var(--background-light);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
    }

    /* 2. Login Box/Card Style */
    .login-box {
      background: #ffffff;
      padding: 40px;
      border-radius: var(--border-radius);
      box-shadow: var(--card-shadow);
      width: 100%;
      max-width: 400px;
      transition: all 0.3s ease;
    }

    /* 3. Header Styling */
    h1 {
      text-align: center;
      color: #eeeaeaff;
      margin-top: 0;
      margin-bottom: 30px;
      font-size: 24px;
      font-weight: 600;
    }

    /* 4. Form and Input Styling */
    form label {
      display: block;
      margin-bottom: 20px;
      font-weight: 500;
      color: #555;
    }

    form input[type="text"],
    form input[type="password"] {
      width: 100%;
      padding: 12px 15px;
      margin-top: 8px;
      box-sizing: border-box;
      border: 1px solid #ccc;
      border-radius: 4px;
      transition: border-color 0.3s, box-shadow 0.3s;
      font-size: 16px;
    }

    form input:focus {
      border-color: var(--primary-color);
      box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25);
      outline: none;
    }

    /* Checkbox/Remember me styling */
    .remember-me {
        display: block;
        margin-bottom: 30px;
        font-weight: 400;
        color: #555;
    }

    /* 5. Button Styling */
    button[type="submit"] {
      width: 100%;
      padding: 12px 20px;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 18px;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s, box-shadow 0.3s;
    }

    button[type="submit"]:hover {
      background-color: var(--primary-dark);
      box-shadow: 0 4px 8px rgba(0, 123, 255, 0.3);
    }

    /* 6. Error Message Styling */
    .error-message {
      color: #d9534f; /* A professional red/danger color */
      background-color: #f2dede;
      border: 1px solid #ebccd1;
      padding: 10px;
      border-radius: 4px;
      text-align: center;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <!-- Added a centered container for elegance -->
  <div class="login-box">
    <h1>Log In to Your Account</h1>

    <?php if ($error): ?>
      <p class="error-message"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <!-- autocomplete="off" on the form and appropriate autocomplete attributes on inputs help reduce browser autofill -->
    <form action="login.php" method="post" autocomplete="off">
      <label>
        Username:
        <input type="text" name="username" required
              autocomplete="username"
              value="<?php echo $preserve_username ? htmlspecialchars($old_username) : ''; ?>">
      </label>
      <label>
        Password:
        <input type="password" name="password" required autocomplete="current-password" value="">
      </label>
      <label class="remember-me">
        <input type="checkbox" name="remember" value="1" autocomplete="off"> Remember me
      </label>
      <button type="submit">Log in</button>
    </form>
  </div>

  <script>
    // If we are NOT preserving the username (i.e., not returning from a failed login),
    // try to clear any browser-autofill value that may appear after logout or successful login.
    (function() {
      var preserve = <?php echo $preserve_username ? 'true' : 'false'; ?>;
      if (!preserve) {
        // Clear username and password fields (defensive against autofill)
        var u = document.querySelector('input[name="username"]');
        var p = document.querySelector('input[name="password"]');
        
        // Function to attempt clearing/resetting field attributes
        function resetField(field) {
            if (field) {
                try {
                    field.value = '';
                    field.setAttribute('autocomplete', 'off');
                } catch (e) {
                    console.error("Autofill reset error:", e);
                }
            }
        }

        resetField(p); // Always try to reset password
        
        if (u) {
            resetField(u);
        }

        // A tiny delay to handle browsers that autofill after DOMContentLoaded
        setTimeout(function() {
          if (u && !preserve) u.value = '';
          if (p) p.value = '';
        }, 50);
      }
    })();
  </script>
</body>
</html>