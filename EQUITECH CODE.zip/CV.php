<?php
// PHP file upload handling logic
// NOTE: For this to work in a real environment, the 'uploads/' directory must exist 
// and be writable by the web server.

$target_dir = "uploads/";
$upload_message = "";

if (isset($_POST["upload_image_submit"])) {
    // Check if the file input 'cv_image' was part of the submission
    if (!isset($_FILES["cv_image"]) || $_FILES["cv_image"]["error"] != UPLOAD_ERR_OK) {
        // Handle common upload errors (e.g., file size limit exceeded by PHP config)
        $error_code = isset($_FILES["cv_image"]) ? $_FILES["cv_image"]["error"] : "N/A";
        $upload_message = "Error: No file uploaded or upload failed with error code: " . $error_code;
    } else {
        $file_name = basename($_FILES["cv_image"]["name"]);
        // Simple security: sanitize filename and create a unique name to prevent overwrites/path traversal issues
        $safe_file_name = preg_replace("/[^a-zA-Z0-9\-\.]/", "", $file_name);
        
        // Use a timestamp and a safe version of the original name to ensure uniqueness
        $target_file = $target_dir . time() . "_" . $safe_file_name;

        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($safe_file_name,PATHINFO_EXTENSION));

        // 1. Check if file is an actual image (using getimagesize)
        $check = getimagesize($_FILES["cv_image"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            $upload_message = "File is not an image.";
            $uploadOk = 0;
        }

        // 2. Check file size (e.g., limit to 5MB)
        if ($_FILES["cv_image"]["size"] > 5000000) {
            $upload_message = "Sorry, your file is too large (max 5MB).";
            $uploadOk = 0;
        }

        // 3. Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            $upload_message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Final upload attempt
        if ($uploadOk == 0) {
            $upload_message = "Sorry, your file was not uploaded. Reason: " . $upload_message;
        } else {
            // Create the directory if it doesn't exist (set permissions for a real server)
            if (!is_dir($target_dir)) {
                if (!mkdir($target_dir, 0777, true)) {
                    $upload_message = "Error: Failed to create upload directory. Check permissions.";
                    $uploadOk = 0;
                }
            }

            if ($uploadOk && move_uploaded_file($_FILES["cv_image"]["tmp_name"], $target_file)) {
                $upload_message = "The file ". htmlspecialchars($safe_file_name). " has been uploaded successfully.";
            } else {
                if($uploadOk) { // Check if move_uploaded_file failed for other reasons
                    $upload_message = "Sorry, there was an error uploading your file. Check directory permissions.";
                }
            }
        }
    }
}
?>

<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EquiTech - CV Automation</title>
  <script src="/_sdk/element_sdk.js"></script>
  <style>
    body {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #190f33;
      color: #ffffff;
      min-height: 100%;
    }

    *, *::before, *::after {
      box-sizing: border-box;
    }

    html {
      height: 100%;
    }

    /* Header */
    header {
      background: linear-gradient(135deg, rgba(25, 15, 51, 0.98), rgba(43, 28, 75, 0.98));
      backdrop-filter: blur(10px);
      padding: 1rem 3rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgba(127, 90, 240, 0.2);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: #ffffff;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    nav {
      display: flex;
      gap: 2.5rem;
      align-items: center;
    }

    nav a {
      color: #cccccc;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s;
      font-size: 0.95rem;
      padding-bottom: 0.25rem;
      border-bottom: 2px solid transparent;
    }

    nav a:hover {
      color: 2px solid rgba(127, 90, 240, 0.6);
    }

     nav a.active {
      color: #ffffff;
      border-bottom: 2px solid rgba(127, 90, 240, 0.6);
    }

    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      background: rgba(127, 90, 240, 0.15);
      padding: 0.5rem 1rem;
      border-radius: 25px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .user-profile:hover {
      background: rgba(127, 90, 240, 0.25);
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 0.85rem;
    }

    .user-info {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }

    .user-name {
      font-weight: 600;
      font-size: 0.9rem;
    }

    .view-profile {
      font-size: 0.75rem;
      color: #cccccc;
    }

    /* Hero Section */
    .hero {
      padding: 4rem 3rem 3rem 3rem;
      max-width: 1400px;
      margin: 0 auto;
    }

    .hero-content {
      text-align: center;
      margin-bottom: 3rem;
    }

    .hero h1 {
      font-size: 3.5rem;
      font-weight: 800;
      margin: 0 0 1rem 0;
      color: #ffffff;
      line-height: 1.2;
    }

    .hero-subtitle {
      font-size: 1.2rem;
      color: #cccccc;
      max-width: 2000px;
      margin: 0 auto 2rem auto;
      line-height: 1.6;
    }

    .view-drafts-btn {
      background: rgba(127, 90, 240, 0.2);
      border: 2px solid #7f5af0;
      color: #ffffff;
      padding: 0.9rem 2rem;
      border-radius: 50px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      font-size: 1rem;
      display: inline-flex;
      align-items: center;
      gap: 0.75rem;
    }

    .view-drafts-btn:hover {
      background: rgba(127, 90, 240, 0.4);
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(127, 90, 240, 0.4);
    }

    /* AI Tools */
    .ai-tools {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
      margin-bottom: 2rem;
    }

    .ai-tool-btn {
      background: linear-gradient(135deg, rgba(74, 144, 226, 0.2), rgba(82, 54, 173, 0.2));
      border: 1px solid rgba(127, 90, 240, 0.3);
      color: #ffffff;
      padding: 0.8rem 1.75rem;
      border-radius: 25px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      font-size: 0.95rem;
    }

    .ai-tool-btn:hover {
      background: linear-gradient(135deg, rgba(74, 144, 226, 0.4), rgba(82, 54, 173, 0.4));
      transform: translateY(-2px);
      box-shadow: 0 4px 16px rgba(127, 90, 240, 0.3);
    }

    /* Search Bar */
    .search-wrapper {
      max-width: 600px;
      margin: 0 auto;
      position: relative;
    }

    .search-container {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(127, 90, 240, 0.3);
      padding: 0.75rem 1.5rem;
      border-radius: 50px;
      display: flex;
      gap: 1rem;
      align-items: center;
    }

    .search-input {
      flex: 1;
      border: none;
      background: transparent;
      color: #ffffff;
      font-size: 1rem;
      outline: none;
    }

    .search-input::placeholder {
      color: #999999;
    }

    .search-icon {
      color: #7f5af0;
      font-size: 1.2rem;
      cursor: pointer;
      transition: transform 0.3s;
    }

    .search-icon:hover {
      transform: scale(1.1);
    }

    /* Automation Section */
    .automation-section {
      padding: 4rem 3rem;
      max-width: 1400px;
      margin: 0 auto;
    }

    .section-title {
      font-size: 2.8rem;
      font-weight: 700;
      text-align: center;
      margin: 0 0 3rem 0;
      color: #ffffff;
    }

    .automation-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 2rem;
      max-width: 900px;
      margin: 0 auto;
    }

    .automation-card {
      background: rgba(43, 28, 75, 0.6);
      border: 2px solid rgba(127, 90, 240, 0.3);
      border-radius: 20px;
      padding: 3rem 2rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
      position: relative;
      overflow: hidden;
    }

    .automation-card::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      border-radius: 50%;
      background: rgba(127, 90, 240, 0.2);
      transform: translate(-50%, -50%);
      transition: width 0.6s, height 0.6s;
    }

    .automation-card:hover::before {
      width: 500px;
      height: 500px;
    }

    .automation-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 12px 40px rgba(127, 90, 240, 0.5);
      border-color: rgba(127, 90, 240, 0.6);
    }

    .card-icon {
      font-size: 4rem;
      margin-bottom: 1.5rem;
      position: relative;
      z-index: 1;
    }

    .card-title {
      font-size: 1.8rem;
      font-weight: 700;
      margin: 0 0 0.75rem 0;
      color: #ffffff;
      position: relative;
      z-index: 1;
    }

    .card-subtitle {
      font-size: 1.1rem;
      color: #cccccc;
      margin: 0;
      position: relative;
      z-index: 1;
    }

    /* Templates Section */
    .templates-section {
      padding: 4rem 3rem;
      background: linear-gradient(180deg, #190f33 0%, #5e5d34 100%);
    }

    .templates-container {
      max-width: 1400px;
      margin: 0 auto;
    }

    .templates-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 2.5rem;
      margin-top: 3rem;
    }

    .template-card {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(127, 90, 240, 0.2);
      border-radius: 16px;
      overflow: hidden;
      cursor: pointer;
      transition: all 0.3s;
    }

    .template-card:hover {
      transform: translateY(-8px) scale(1.02);
      box-shadow: 0 16px 48px rgba(127, 90, 240, 0.4);
      border-color: rgba(127, 90, 240, 0.5);
    }

    .template-image {
      width: 100%;
      height: 400px;
      background: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
    }

    .resume-preview {
      width: 90%;
      height: 90%;
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
      border-radius: 8px;
      padding: 2rem 1.5rem;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      position: relative;
    }

    .resume-header {
      margin-bottom: 1rem;
      padding-bottom: 1rem;
      border-bottom: 3px solid #5236ad;
    }

    .resume-name {
      font-size: 1.5rem;
      font-weight: 800;
      color: #190f33;
      margin: 0 0 0.25rem 0;
    }

    .resume-title-text {
      font-size: 0.75rem;
      color: #666666;
      margin: 0;
    }

    .resume-section {
      margin-bottom: 0.75rem;
    }

    .resume-section-title {
      font-size: 0.65rem;
      font-weight: 700;
      color: #5236ad;
      text-transform: uppercase;
      margin: 0 0 0.25rem 0;
      letter-spacing: 0.5px;
    }

    .resume-content {
      font-size: 0.5rem;
      color: #333333;
      line-height: 1.3;
    }

    .resume-bars {
      display: flex;
      gap: 0.25rem;
      margin-top: 0.25rem;
    }

    .resume-bar {
      height: 4px;
      background: #5236ad;
      border-radius: 2px;
    }

    .template-info {
      padding: 1.5rem;
      text-align: center;
    }

    .template-title {
      font-size: 1.3rem;
      font-weight: 700;
      color: #ffffff;
      margin: 0;
    }

    /* Responsive */
    @media (max-width: 1024px) {
      header {
        padding: 1rem 2rem;
      }

      .hero {
        padding: 3rem 2rem;
      }

      .hero h1 {
        font-size: 2.8rem;
      }

      .section-title {
        font-size: 2.2rem;
      }

      nav {
        gap: 1.5rem;
      }
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        gap: 1rem;
        padding: 1rem;
      }

      nav {
        flex-wrap: wrap;
        justify-content: center;
        gap: 1rem;
      }

      .hero h1 {
        font-size: 2rem;
      }

      .hero-subtitle {
        font-size: 1rem;
      }

      .section-title {
        font-size: 1.8rem;
      }

      .ai-tools {
        flex-direction: column;
        align-items: stretch;
      }

      .automation-cards {
        grid-template-columns: 1fr;
      }

      .templates-grid {
        grid-template-columns: 1fr;
      }
    }

     /* User Profile */
    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7C3AED 0%, #A78BFA 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
    }
    .user-info {
      display: flex;
      flex-direction: column;
      color:white;
    }
    .user-info span {
      font-weight: 600;
      font-size: 0.95rem;
    }
    .user-info a {
      color: #7C3AED;
      font-size: 0.8rem;
      text-decoration: none;
    }
  </style>
  <style>@view-transition { navigation: auto; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
  <script src="https://cdn.tailwindcss.com" type="text/javascript"></script>
 </head>
 <body>
  <header>
    <div class="logo" id="site-name">
      EquiTech
    </div>
    <nav>
      <a href="aboutus.php">About us</a>
      <a href="E-Learning.php">E-Learning</a>
      <a href="Training.php">Trainings</a>
      <a href="Findjob.php">Find Job</a>
      <a href="CV.php" class="active">CV Automation</a>
    </nav>
   <div class="user-profile">
      <div class="user-avatar">
       RJ
      </div>
      <div class="user-info"><span id="user-name-display">RIEL JAKE E.</span> <a href="Userprofile.php">View profile</a>
      </div>
     </div>
    </div>
  </header>
  <main>
    <section class="hero">
      <div class="hero-content">
        <h1 id="hero-title">Fast and Secure CV Automation</h1>
        <p class="hero-subtitle" id="hero-subtitle">All of the Workshops, Trainings Certifications that has been completed, will automatically added in your CV</p>
        <button class="view-drafts-btn" id="view-drafts-btn">
          <span>⭕</span>
          <span id="drafts-text">View CV Drafts</span>
        </button>
      </div>
      <div class="ai-tools">
        <button class="ai-tool-btn">✍️ AI Write</button>
        <button class="ai-tool-btn">📋 AI Job Description Maker</button>
        <button class="ai-tool-btn">🔄 AI Paraphrase</button>
      </div>
      <div class="search-wrapper">
        <div class="search-container">
          <input type="text" class="search-input" id="template-search" placeholder="Find CV Templates">
          <span class="search-icon">🔍</span>
        </div>
      </div>
    </section>
    <section class="automation-section">
      <h2 class="section-title" id="automation-title">Automate your CV now</h2>
      <div class="automation-cards">
        <div class="automation-card">
          <div class="card-icon">
            📝
          </div>
          <h3 class="card-title" id="form-card-title">Fill a form</h3>
          <p class="card-subtitle" id="form-card-subtitle">Fill up your form</p>
        </div>
        <div class="automation-card">
          <div class="card-icon">
            📤
          </div>
          <h3 class="card-title" id="upload-card-title">Upload Image</h3>
          <p class="card-subtitle" id="upload-card-subtitle">Upload your CV Image</p>
        </div>
      </div>
    </section>
    <section class="templates-section">
      <div class="templates-container">
        <h2 class="section-title" id="templates-title">CV Templates</h2>
        <div class="templates-grid">
          <div class="template-card">
            <div class="template-image">
              <div class="resume-preview">
                <div class="resume-header">
                  <div class="resume-name">
                    DANIELLE SCOTT
                  </div>
                  <div class="resume-title-text">
                    Marketing Professional
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    SKILLS
                  </div>
                  <div class="resume-content">
                    Digital Marketing
                  </div>
                  <div class="resume-bars">
                    <div class="resume-bar" style="width: 50px;"></div>
                    <div class="resume-bar" style="width: 40px;"></div>
                    <div class="resume-bar" style="width: 30px;"></div>
                  </div>
                  <div class="resume-content" style="margin-top: 0.5rem;">
                    Social Media Strategy
                  </div>
                  <div class="resume-bars">
                    <div class="resume-bar" style="width: 45px;"></div>
                    <div class="resume-bar" style="width: 35px;"></div>
                    <div class="resume-bar" style="width: 25px;"></div>
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    EDUCATION
                  </div>
                  <div class="resume-content">
                    Bachelor of Business Administration
                  </div>
                  <div class="resume-content">
                    University of Marketing • 2018-2022
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    CERTIFICATIONS
                  </div>
                  <div class="resume-content">
                    • Google Analytics Certified
                  </div>
                  <div class="resume-content">
                    • HubSpot Marketing
                  </div>
                </div>
              </div>
            </div>
            <div class="template-info">
              <h3 class="template-title" id="template-1-title">Functional Resume</h3>
            </div>
          </div>
          <div class="template-card">
            <div class="template-image">
              <div class="resume-preview">
                <div class="resume-header">
                  <div class="resume-name">
                    ROBEN WILLIAM
                  </div>
                  <div class="resume-title-text">
                    Software Engineer
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    PROFESSIONAL SUMMARY
                  </div>
                  <div class="resume-content">
                    Experienced software engineer with expertise in full-stack development and cloud technologies.
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    KEY SKILLS
                  </div>
                  <div class="resume-content">
                    JavaScript • Python • React • Node.js • AWS
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    EXPERIENCE
                  </div>
                  <div class="resume-content">
                    Senior Developer | TechCorp
                  </div>
                  <div class="resume-content">
                    2020 - Present
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    EDUCATION
                  </div>
                  <div class="resume-content">
                    BS Computer Science • MIT • 2016-2020
                  </div>
                </div>
              </div>
            </div>
            <div class="template-info">
              <h3 class="template-title" id="template-2-title">Combination Resume</h3>
            </div>
          </div>
          <div class="template-card">
            <div class="template-image">
              <div class="resume-preview">
                <div class="resume-header">
                  <div class="resume-name">
                    GAIL WALDSOR
                  </div>
                  <div class="resume-title-text">
                    Project Manager
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    WORK EXPERIENCE
                  </div>
                  <div class="resume-content">
                    Senior Project Manager
                  </div>
                  <div class="resume-content">
                    GlobalTech Inc. | 2021 - Present
                  </div>
                  <div class="resume-content" style="margin-top: 0.3rem;">
                    • Led 15+ cross-functional teams
                  </div>
                  <div class="resume-content">
                    • Delivered projects worth $5M+
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-content">
                    Project Coordinator
                  </div>
                  <div class="resume-content">
                    StartupHub | 2018 - 2021
                  </div>
                  <div class="resume-content" style="margin-top: 0.3rem;">
                    • Managed agile workflows
                  </div>
                  <div class="resume-content">
                    • Coordinated 8 product launches
                  </div>
                </div>
                <div class="resume-section">
                  <div class="resume-section-title">
                    EDUCATION
                  </div>
                  <div class="resume-content">
                    MBA | Harvard Business School
                  </div>
                </div>
              </div>
            </div>
            <div class="template-info">
              <h3 class="template-title" id="template-3-title">Chronological Resume</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<footer style="background: #0D0021; border-top: 1px solid #2D1B4E; padding: 3rem 0 2rem;">
   <div style="max-width: 1400px; margin: 0 auto; padding: 0 2rem;">
    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 3rem; margin-bottom: 3rem;"><!-- Company Info -->
     <div>
      <div style="font-size: 1.75rem; font-weight: 700; margin-bottom: 1rem;"><span style="color: #ffffff;" id="footer-brand-name">EquiTech</span>
      </div>
      <p style="color: #9CA3AF; line-height: 1.6; margin-bottom: 1.5rem;" id="footer-tagline-display">We have right mentors for any job. EquiTech will help you learn to code and help you to connect with them easily and effectively.</p><!-- Social Icons -->
      <div style="display: flex; gap: 1rem;">
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
       </div>
      </div>
     </div><!-- Product -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Product</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Features</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Pricing</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Integrations</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Changelog</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div><!-- Resources -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Resources</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Documentation</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Tutorials</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Blogs</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Support</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">FAQ</a></li>
      </ul>
     </div><!-- Company -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Company</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">About</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Careers</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Contact</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Partners</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div>
    </div><!-- Copyright -->
    <div style="border-top: 1px solid #2D1B4E; padding-top: 2rem; text-align: center;">
     <p style="color: #6B7280; font-size: 0.9rem; margin: 0;">© 2022 EquiTech. All rights reserved.</p>
    </div>
   </div>
  </footer>
  </body>
  <script>
  const defaultConfig = {
    site_name: "💼 EquiTech",
    user_name: "RIEL JAKE E.",
    hero_title: "Fast and Secure CV Automation",
    hero_subtitle: "All of the Workshops, Trainings Certifications that has been completed, will automatically added in your CV",
    view_drafts_button: "View CV Drafts",
    search_placeholder: "Find CV Templates",
    automation_title: "Automate your CV now",
    form_card_title: "Fill a form",
    form_card_subtitle: "Fill up your form",
    upload_card_title: "Upload Image",
    upload_card_subtitle: "Upload your CV Image",
    templates_title: "CV Templates",
    template_1_title: "Functional Resume",
    template_2_title: "Combination Resume",
    template_3_title: "Chronological Resume",
    background_color: "#190f33",
    surface_color: "rgba(43, 28, 75, 0.6)",
    text_color: "#ffffff",
    primary_action_color: "#5236ad",
    accent_color: "#7f5af0",
    font_family: "sans-serif",
    font_size: 16
  };

  // All notification-generating click handlers (for AI tools, search, cards, and drafts button) have been removed.

  async function onConfigChange(config) {
    const customFont = config.font_family || defaultConfig.font_family;
    const baseFontStack = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
    const fontFamily = `${customFont}, ${baseFontStack}`;
    const baseSize = config.font_size || defaultConfig.font_size;
    
    document.body.style.fontFamily = fontFamily;
    document.body.style.fontSize = `${baseSize}px`;
    document.body.style.background = config.background_color || defaultConfig.background_color;
    document.body.style.color = config.text_color || defaultConfig.text_color;

    const automationCards = document.querySelectorAll('.automation-card');
    automationCards.forEach(card => {
      card.style.background = config.surface_color || defaultConfig.surface_color;
    });

    const accentElements = document.querySelectorAll('nav a.active, .search-icon');
    accentElements.forEach(el => {
      el.style.color = config.accent_color || defaultConfig.accent_color;
    });

    document.getElementById('site-name').textContent = config.site_name || defaultConfig.site_name;
    document.getElementById('user-name').textContent = config.user_name || defaultConfig.user_name;
    document.getElementById('hero-title').textContent = config.hero_title || defaultConfig.hero_title;
    document.getElementById('hero-subtitle').textContent = config.hero_subtitle || defaultConfig.hero_subtitle;
    document.getElementById('drafts-text').textContent = config.view_drafts_button || defaultConfig.view_drafts_button;
    document.getElementById('template-search').placeholder = config.search_placeholder || defaultConfig.search_placeholder;
    document.getElementById('automation-title').textContent = config.automation_title || defaultConfig.automation_title;
    document.getElementById('form-card-title').textContent = config.form_card_title || defaultConfig.form_card_title;
    document.getElementById('form-card-subtitle').textContent = config.form_card_subtitle || defaultConfig.form_card_subtitle;
    document.getElementById('upload-card-title').textContent = config.upload_card_title || defaultConfig.upload_card_title;
    document.getElementById('upload-card-subtitle').textContent = config.upload_card_subtitle || defaultConfig.upload_card_subtitle;
    document.getElementById('templates-title').textContent = config.templates_title || defaultConfig.templates_title;
    document.getElementById('template-1-title').textContent = config.template_1_title || defaultConfig.template_1_title;
    document.getElementById('template-2-title').textContent = config.template_2_title || defaultConfig.template_2_title;
    document.getElementById('template-3-title').textContent = config.template_3_title || defaultConfig.template_3_title;

    const heroTitle = document.querySelector('.hero h1');
    if (heroTitle) heroTitle.style.fontSize = `${baseSize * 3.5}px`;
    
    const heroSubtitle = document.querySelector('.hero-subtitle');
    if (heroSubtitle) heroSubtitle.style.fontSize = `${baseSize * 1.2}px`;
    
    const sectionTitles = document.querySelectorAll('.section-title');
    sectionTitles.forEach(title => {
      title.style.fontSize = `${baseSize * 2.8}px`;
    });
  }

  function mapToCapabilities(config) {
    return {
      recolorables: [
        {
          get: () => config.background_color || defaultConfig.background_color,
          set: (value) => {
            config.background_color = value;
            window.elementSdk.setConfig({ background_color: value });
          }
        },
        {
          get: () => config.surface_color || defaultConfig.surface_color,
          set: (value) => {
            config.surface_color = value;
            window.elementSdk.setConfig({ surface_color: value });
          }
        },
        {
          get: () => config.text_color || defaultConfig.text_color,
          set: (value) => {
            config.text_color = value;
            window.elementSdk.setConfig({ text_color: value });
          }
        },
        {
          get: () => config.primary_action_color || defaultConfig.primary_action_color,
          set: (value) => {
            config.primary_action_color = value;
            window.elementSdk.setConfig({ primary_action_color: value });
          }
        },
        {
          get: () => config.accent_color || defaultConfig.accent_color,
          set: (value) => {
            config.accent_color = value;
            window.elementSdk.setConfig({ accent_color: value });
          }
        }
      ],
      borderables: [],
      fontEditable: {
        get: () => config.font_family || defaultConfig.font_family,
        set: (value) => {
          config.font_family = value;
          window.elementSdk.setConfig({ font_family: value });
        }
      },
      fontSizeable: {
        get: () => config.font_size || defaultConfig.font_size,
        set: (value) => {
          config.font_size = value;
          window.elementSdk.setConfig({ font_size: value });
        }
      }
    };
  }

  function mapToEditPanelValues(config) {
    return new Map([
      ["site_name", config.site_name || defaultConfig.site_name],
      ["user_name", config.user_name || defaultConfig.user_name],
      ["hero_title", config.hero_title || defaultConfig.hero_title],
      ["hero_subtitle", config.hero_subtitle || defaultConfig.hero_subtitle],
      ["view_drafts_button", config.view_drafts_button || defaultConfig.view_drafts_button],
      ["search_placeholder", config.search_placeholder || defaultConfig.search_placeholder],
      ["automation_title", config.automation_title || defaultConfig.automation_title],
      ["form_card_title", config.form_card_title || defaultConfig.form_card_title],
      ["form_card_subtitle", config.form_card_subtitle || defaultConfig.form_card_subtitle],
      ["upload_card_title", config.upload_card_title || defaultConfig.upload_card_title],
      ["upload_card_subtitle", config.upload_card_subtitle || defaultConfig.upload_card_subtitle],
      ["templates_title", config.templates_title || defaultConfig.templates_title],
      ["template_1_title", config.template_1_title || defaultConfig.template_1_title],
      ["template_2_title", config.template_2_title || defaultConfig.template_2_title],
      ["template_3_title", config.template_3_title || defaultConfig.template_3_title]
    ]);
  }

  if (window.elementSdk) {
    window.elementSdk.init({
      defaultConfig,
      onConfigChange,
      mapToCapabilities,
      mapToEditPanelValues
    });
  }
</script>
</html>