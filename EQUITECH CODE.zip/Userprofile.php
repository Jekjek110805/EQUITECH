<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EquiTech - Profile</title>
  <script src="/_sdk/element_sdk.js"></script>
  <style>
    body {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #190f33;
      color: #ffffff;
      min-height: 100%;
    }

    *, *::before, *::after {
      box-sizing: border-box;
    }

    html {
      height: 100%;
    }

    /* Header */
    header {
      background: linear-gradient(135deg, rgba(25, 15, 51, 0.98), rgba(43, 28, 75, 0.98));
      backdrop-filter: blur(10px);
      padding: 1rem 3rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgba(127, 90, 240, 0.2);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: #ffffff;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    nav {
      display: flex;
      gap: 2.5rem;
      align-items: center;
    }

    nav a {
      color: #cccccc;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s;
      font-size: 0.95rem;
      padding-bottom: 0.25rem;
      border-bottom: 2px solid transparent;
    }

    nav a:hover {
      color: #ffffff;
    }

    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      background: rgba(127, 90, 240, 0.15);
      padding: 0.5rem 1rem;
      border-radius: 25px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .user-profile:hover {
      background: rgba(127, 90, 240, 0.25);
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 0.85rem;
    }

    .user-info {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }

    .user-name {
      font-weight: 600;
      font-size: 0.9rem;
    }

    .view-profile {
      font-size: 0.75rem;
      color: #cccccc;
    }

    /* Main Content */
    .main-content {
      max-width: 1400px;
      margin: 0 auto;
      padding: 3rem;
    }

    .content-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
      margin-bottom: 3rem;
    }

    /* Profile Card */
    .profile-card {
      background: linear-gradient(135deg, rgba(43, 28, 75, 0.8), rgba(62, 42, 109, 0.6));
      border: 1px solid rgba(127, 90, 240, 0.3);
      border-radius: 20px;
      padding: 2.5rem;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }

    .profile-header {
      display: flex;
      gap: 1.5rem;
      align-items: flex-start;
      margin-bottom: 2rem;
    }

    .profile-picture {
      width: 100px;
      height: 100px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2.5rem;
      border: 3px solid rgba(127, 90, 240, 0.4);
      flex-shrink: 0;

    }

    .profile-info {
      flex: 1;
    }

    .profile-name {
      font-size: 1.8rem;
      font-weight: 700;
      margin: 0 0 0.5rem 0;
      color: #ffffff;
    }

    .profile-badges {
      display: flex;
      gap: 0.75rem;
      flex-wrap: wrap;
      margin-bottom: 1rem;
    }

    .badge {
      padding: 0.4rem 1rem;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 600;
    }

    .badge-role {
      background: linear-gradient(135deg, #d946a8, #b91c8f);
      color: #ffffff;
    }

    .badge-verified {
      background: rgba(39, 126, 255, 1);
      color: #ffffffff;
      border: 1px solid #0c1fd1ff;
    }

    .profile-details {
      display: grid;
      gap: 1.5rem;
    }

    .detail-section {
      position: relative;
    }

    .detail-label {
      font-size: 0.85rem;
      color: #999999;
      margin-bottom: 0.5rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .detail-content {
      font-size: 1rem;
      color: #ffffff;
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }

    .skill-tag {
      background: rgba(127, 90, 240, 0.2);
      color: #ffffff;
      padding: 0.4rem 1rem;
      border-radius: 15px;
      font-size: 0.85rem;
      border: 1px solid rgba(127, 90, 240, 0.4);
      cursor: pointer;
      transition: all 0.3s;
      position: relative;
    }

    .skill-tag:hover {
      background: rgba(127, 90, 240, 0.4);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(127, 90, 240, 0.4);
    }

    .tooltip {
      position: absolute;
      bottom: 120%;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(0, 0, 0, 0.95);
      color: #ffffff;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      font-size: 0.8rem;
      white-space: nowrap;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s;
      z-index: 100;
    }

    .tooltip::after {
      content: '';
      position: absolute;
      top: 100%;
      left: 50%;
      transform: translateX(-50%);
      border: 6px solid transparent;
      border-top-color: rgba(0, 0, 0, 0.95);
    }

    .skill-tag:hover .tooltip {
      opacity: 1;
    }

    .job-application {
      background: rgba(0, 0, 0, 0.2);
      padding: 1rem;
      border-radius: 12px;
      display: flex;
      gap: 1rem;
      align-items: center;
    }

    .job-logo {
      width: 50px;
      height: 50px;
      border-radius: 8px;
      background: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      color: #190f33;
      font-size: 0.8rem;
      text-align: center;
      padding: 0.25rem;
    }

    .job-details {
      flex: 1;
    }

    .job-title {
      font-weight: 600;
      margin-bottom: 0.25rem;
    }

    .job-company {
      font-size: 0.85rem;
      color: #cccccc;
    }

    /* Metrics Section */
    .metrics-section {
      display: flex;
      flex-direction: column;
      gap: 2rem;
    }

    .metrics-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1rem;
    }

    .metric-card {
      background: linear-gradient(135deg, rgba(43, 28, 75, 0.8), rgba(62, 42, 109, 0.6));
      border: 1px solid rgba(127, 90, 240, 0.3);
      border-radius: 16px;
      padding: 1.5rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
      position: relative;
    }

    .metric-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 24px rgba(127, 90, 240, 0.4);
      border-color: rgba(127, 90, 240, 0.6);
    }

    .metric-value {
      font-size: 2.5rem;
      font-weight: 800;
      margin: 0 0 0.5rem 0;
      background: linear-gradient(135deg, #7f5af0, #4a90e2);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .metric-label {
      font-size: 0.9rem;
      color: #cccccc;
      font-weight: 500;
    }

    /* Aspect Score */
    .aspect-score-card {
      background: linear-gradient(135deg, rgba(43, 28, 75, 0.8), rgba(62, 42, 109, 0.6));
      border: 1px solid rgba(127, 90, 240, 0.3);
      border-radius: 20px;
      padding: 2.5rem;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }

    .section-title {
      font-size: 1.8rem;
      font-weight: 700;
      margin: 0 0 2rem 0;
      color: #ffffff;
    }

    .chart-container {
      display: flex;
      gap: 3rem;
      align-items: center;
    }

    .chart-visual {
      position: relative;
      width: 250px;
      height: 250px;
      flex-shrink: 0;
    }

    .pie-chart {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background: conic-gradient(
        from 0deg,
        #4a90e2 0deg 80deg,
        #7f5af0 80deg 150deg,
        #d946a8 150deg 210deg,
        #22c55e 210deg 260deg,
        #f59e0b 260deg 300deg,
        #ef4444 300deg 330deg,
        #8b5cf6 330deg 360deg
      );
      position: relative;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }

    .pie-center {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 140px;
      height: 140px;
      border-radius: 50%;
      background: linear-gradient(135deg, #2b1c4b, #190f33);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      border: 3px solid rgba(127, 90, 240, 0.4);
    }

    .score-value {
      font-size: 2.5rem;
      font-weight: 800;
      color: #ffffff;
    }

    .score-label {
      font-size: 0.85rem;
      color: #cccccc;
      margin-top: 0.25rem;
    }

    .chart-legend {
      flex: 1;
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 1rem;
    }

    .legend-item {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.75rem;
      background: rgba(0, 0, 0, 0.2);
      border-radius: 10px;
      transition: all 0.3s;
      cursor: pointer;
    }

    .legend-item:hover {
      background: rgba(0, 0, 0, 0.4);
      transform: translateX(4px);
    }

    .legend-color {
      width: 16px;
      height: 16px;
      border-radius: 4px;
      flex-shrink: 0;
    }

    .legend-text {
      font-size: 0.9rem;
      color: #ffffff;
    }

    /* Active Interviews */
    .interviews-section {
      margin-top: 3rem;
    }

    .interviews-header {
      margin-bottom: 2rem;
    }

    .interviews-title {
      font-size: 2rem;
      font-weight: 700;
      margin: 0 0 0.5rem 0;
      color: #ffffff;
    }

    .interviews-subtitle {
      font-size: 1.1rem;
      color: #cccccc;
      margin: 0;
    }

    .interviews-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 2rem;
    }

    .interview-card {
      background: linear-gradient(135deg, rgba(43, 28, 75, 0.8), rgba(62, 42, 109, 0.6));
      border: 3px solid;
      border-radius: 20px;
      padding: 3rem 2rem;
      text-align: center;
      transition: all 0.3s;
      cursor: pointer;
    }

    .interview-card.all {
      border-color: #f59e0b;
      background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(43, 28, 75, 0.8));
    }

    .interview-card.new {
      border-color: #4a90e2;
      background: linear-gradient(135deg, rgba(74, 144, 226, 0.1), rgba(43, 28, 75, 0.8));
    }

    .interview-card.screening {
      border-color: #22c55e;
      background: linear-gradient(135deg, rgba(34, 197, 94, 0.1), rgba(43, 28, 75, 0.8));
    }

    .interview-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 12px 40px rgba(127, 90, 240, 0.5);
    }

    .interview-count {
      font-size: 5rem;
      font-weight: 800;
      margin: 0 0 0.5rem 0;
      line-height: 1;
    }

    .interview-card.all .interview-count {
      color: #f59e0b;
    }

    .interview-card.new .interview-count {
      color: #4a90e2;
    }

    .interview-card.screening .interview-count {
      color: #22c55e;
    }

    .interview-label {
      font-size: 1.3rem;
      color: #cccccc;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    /* Footer */
    footer {
      background: linear-gradient(135deg, #5e5d34, #706e30);
      padding: 4rem 3rem 2rem 3rem;
      margin-top: 4rem;
    }

    .footer-content {
      max-width: 1400px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr;
      gap: 3rem;
      margin-bottom: 2rem;
    }

    .footer-brand {
      max-width: 400px;
    }

    .footer-logo {
      font-size: 1.8rem;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 1rem;
    }

    .footer-mission {
      font-size: 0.95rem;
      color: #cccccc;
      line-height: 1.7;
      margin-bottom: 1.5rem;
    }

    .social-links {
      display: flex;
      gap: 1rem;
    }

    .social-icon {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .social-icon:hover {
      background: rgba(127, 90, 240, 0.4);
      transform: translateY(-4px);
    }

    .footer-column h3 {
      font-size: 1.1rem;
      font-weight: 700;
      margin: 0 0 1.5rem 0;
      color: #ffffff;
    }

    .footer-links {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }

    .footer-links a {
      color: #cccccc;
      text-decoration: none;
      font-size: 0.95rem;
      transition: all 0.3s;
    }

    .footer-links a:hover {
      color: #ffffff;
      padding-left: 0.5rem;
    }

    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding-top: 2rem;
      text-align: center;
      color: #cccccc;
      font-size: 0.9rem;
    }

    /* Responsive */
    @media (max-width: 1200px) {
      .content-grid {
        grid-template-columns: 1fr;
      }

      .chart-container {
        flex-direction: column;
      }

      .chart-legend {
        grid-template-columns: 1fr;
      }

      .footer-content {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        gap: 1rem;
        padding: 1rem;
      }

      nav {
        flex-wrap: wrap;
        justify-content: center;
        gap: 1rem;
      }

      .main-content {
        padding: 2rem 1rem;
      }

      .metrics-grid {
        grid-template-columns: 1fr;
      }

      .interviews-grid {
        grid-template-columns: 1fr;
      }

      .footer-content {
        grid-template-columns: 1fr;
        gap: 2rem;
      }

      .profile-header {
        flex-direction: column;
        align-items: center;
        text-align: center;
      }
    }
  </style>
  <style>@view-transition { navigation: auto; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
  <script src="https://cdn.tailwindcss.com" type="text/javascript"></script>
 </head>
 <body>
  <header>
   <div class="logo" id="site-name">
    EquiTech
   </div>
   <nav><a href="aboutus.php">About us</a> <a href="E-Learning.php">E-Learning</a> <a href="Training.php">Trainings</a> <a href="Findjob.php">Find Job</a> <a href="CV.php">CV Automation</a>
   </nav>
   <div class="user-profile">
    <div class="user-avatar">
RJ
    </div>
    <div class="user-info">
     <div class="user-name" id="user-name">
      JAKE E.
     </div>
     <div class="view-profile">
      View profile
     </div>
    </div>
   </div>
  </header>
  <main class="main-content">
   <div class="content-grid"><!-- Profile Card -->
    <div class="profile-card">
     <div class="profile-header">
      <div class="profile-picture"><img src="https://scontent.fceb5-1.fna.fbcdn.net/v/t39.30808-6/557828090_1519298899196701_7239957792481800245_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=a5f93a&_nc_eui2=AeGxKyvOuSXK7CVojHit9qtX89tbBH8ofQrz21sEfyh9Cl0T1P74oHrIki2hgv6dxU2PuNGRFeZkpL45Pqm1K7Hq&_nc_ohc=UpIz_NeG_i4Q7kNvwG1h8lj&_nc_oc=Adm99F1wVjvKd6ouzEp-A_f-QczN0qrKOdalTCNSDamPzCV1C7Cpk6tYF17ogkas7Ms&_nc_zt=23&_nc_ht=scontent.fceb5-1.fna&_nc_gid=scWAL_R-xSLXtZIVZXVLxg&oh=00_AfjdxoKbNJGNiJIfMeVzYozRlsIr8HupqwycVTEuNIQHJA&oe=6927990E" tyle="width: 100%; height: 100%; object-fit: fill;">
      </div>
      <div class="profile-info">
       <h1 class="profile-name" id="profile-full-name">RIEL JAKE ENGAÑA</h1>
       <div class="profile-badges"><span class="badge badge-role" id="profile-role">Developer</span> <span class="badge badge-verified">✓ Verified</span>
       </div>
      </div>
     </div>
     <div class="profile-details">
      <div class="detail-section">
       <div class="detail-label">
        Skills
       </div>
       <div class="detail-content"><span class="skill-tag"> Angular <span class="tooltip">Frontend Framework</span> </span> <span class="skill-tag"> Javascript <span class="tooltip">Programming Language</span> </span> <span class="skill-tag"> HTML <span class="tooltip">Markup Language</span> </span> <span class="skill-tag"> NodeJS <span class="tooltip">Backend Runtime</span> </span> <span class="skill-tag"> C++/C <span class="tooltip">System Programming</span> </span>
       </div>
      </div>
      <div class="detail-section">
       <div class="detail-label">
        Position Type
       </div>
       <div class="detail-content" id="profile-position">
        Remote, Full-time
       </div>
      </div>
      <div class="detail-section">
       <div class="detail-label">
        Location
       </div>
       <div class="detail-content" id="profile-location">
        📍 Philippines, Cebu
       </div>
      </div>
      <div class="detail-section">
       <div class="detail-label">
        Timezone
       </div>
       <div class="detail-content" id="profile-timezone">
        🕐 UTC +8 (08:00)
       </div>
      </div>
      <div class="detail-section">
       <div class="detail-label">
        Job Applications
       </div>
       <div class="job-application">
        <div class="job-logo">
         DW
        </div>
        <div class="job-details">
         <div class="job-title">
          Senior Animation Character
         </div>
         <div class="job-company">
          Dreamworks Animator S/O
         </div>
        </div>
       </div>
      </div>
     </div>
    </div><!-- Metrics Section -->
    <div class="metrics-section">
     <div class="metrics-grid">
      <div class="metric-card">
       <div class="metric-value" id="ability-test-score">
        91%
       </div>
       <div class="metric-label">
        Ability Test
       </div><span class="tooltip">Assessment Score</span>
      </div>
      <div class="metric-card">
       <div class="metric-value" id="availability-score">
        94%
       </div>
       <div class="metric-label">
        Availability
       </div><span class="tooltip">Work Availability</span>
      </div>
      <div class="metric-card">
       <div class="metric-value" id="leadership-score">
        50%
       </div>
       <div class="metric-label">
        Leadership
       </div><span class="tooltip">Leadership Skills</span>
      </div>
     </div><!-- Aspect Score -->
     <div class="aspect-score-card">
      <h2 class="section-title">Aspect Score</h2>
      <div class="chart-container">
       <div class="chart-visual">
        <div class="pie-chart">
         <div class="pie-center">
          <div class="score-value" id="aspect-score">
           1851.9
          </div>
          <div class="score-label">
           Total Score
          </div>
         </div>
        </div>
       </div>
       <div class="chart-legend">
        <div class="legend-item">
         <div class="legend-color" style="background: #4a90e2;"></div>
         <div class="legend-text">
          Figma
         </div>
        </div>
        <div class="legend-item">
         <div class="legend-color" style="background: #7f5af0;"></div>
         <div class="legend-text">
          Sketch
         </div>
        </div>
        <div class="legend-item">
         <div class="legend-color" style="background: #d946a8;"></div>
         <div class="legend-text">
          Webflow
         </div>
        </div>
        <div class="legend-item">
         <div class="legend-color" style="background: #22c55e;"></div>
         <div class="legend-text">
          JavaScript
         </div>
        </div>
        <div class="legend-item">
         <div class="legend-color" style="background: #f59e0b;"></div>
         <div class="legend-text">
          Python
         </div>
        </div>
        <div class="legend-item">
         <div class="legend-color" style="background: #ef4444;"></div>
         <div class="legend-text">
          React
         </div>
        </div>
        <div class="legend-item">
         <div class="legend-color" style="background: #8b5cf6;"></div>
         <div class="legend-text">
          Angular
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div><!-- Active Interviews -->
   <section class="interviews-section">
    <div class="interviews-header">
     <h2 class="interviews-title" id="interviews-title">Jake's active Interviews</h2>
     <p class="interviews-subtitle" id="interviews-role">Front-end Developer • Dreamworks Animation SKG</p>
    </div>
    <div class="interviews-grid">
     <div class="interview-card all">
      <div class="interview-count" id="interviews-all">
       72
      </div>
      <div class="interview-label">
       All
      </div>
     </div>
     <div class="interview-card new">
      <div class="interview-count" id="interviews-new">
       45
      </div>
      <div class="interview-label">
       New
      </div>
     </div>
     <div class="interview-card screening">
      <div class="interview-count" id="interviews-screening">
       0
      </div>
      <div class="interview-label">
       Screening
      </div>
     </div>
    </div>
   </section>
  </main>
    <footer style="background: #0D0021; border-top: 1px solid #2D1B4E; padding: 3rem 0 2rem;">
   <div style="max-width: 1400px; margin: 0 auto; padding: 0 2rem;">
    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 3rem; margin-bottom: 3rem;"><!-- Company Info -->
     <div>
      <div style="font-size: 1.75rem; font-weight: 700; margin-bottom: 1rem;"><span style="color: #ffffff;" id="footer-brand-name">EquiTech</span>
      </div>
      <p style="color: #9CA3AF; line-height: 1.6; margin-bottom: 1.5rem;" id="footer-tagline-display">We have right mentors for any job. EquiTech will help you learn to code and help you to connect with them easily and effectively.</p><!-- Social Icons -->
      <div style="display: flex; gap: 1rem;">
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
       </div>
      </div>
     </div><!-- Product -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Product</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Features</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Pricing</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Integrations</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Changelog</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div><!-- Resources -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Resources</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Documentation</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Tutorials</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Blogs</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Support</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">FAQ</a></li>
      </ul>
     </div><!-- Company -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Company</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">About</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Careers</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Contact</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Partners</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div>
    </div><!-- Copyright -->
    <div style="border-top: 1px solid #2D1B4E; padding-top: 2rem; text-align: center;">
     <p style="color: #6B7280; font-size: 0.9rem; margin: 0;">© 2022 EquiTech. All rights reserved.</p>
    </div>
   </div>
  </footer>
  <script>
    const defaultConfig = {
      site_name: "💼 EquiTech",
      user_name: "RIEL JAKE E.",
      profile_full_name: "RIEL JAKE ENGAÑA,
      profile_role: "Developer",
      profile_position: "Remote, Full-time",
      profile_location: "📍 Philippines, Cebu",
      profile_timezone: "🕐 UTC +8 (08:00)",
      ability_test_score: "91%",
      availability_score: "94%",
      leadership_score: "50%",
      aspect_score: "1851.9",
      interviews_title: "Jake's active Interviews",
      interviews_role: "Front-end Developer • Dreamworks Animation SKG",
      interviews_all: "72",
      interviews_new: "45",
      interviews_screening: "0",
      footer_mission: "We have right mentors for any job. EquiTech will find your right mentor and help you to connect with them easily and effectively",
      background_color: "#190f33",
      surface_color: "rgba(43, 28, 75, 0.8)",
      text_color: "#ffffff",
      primary_action_color: "#5236ad",
      accent_color: "#7f5af0",
      font_family: "sans-serif",
      font_size: 16
    };

    // Interactive tooltips for metric cards
    document.querySelectorAll('.metric-card').forEach(card => {
      card.addEventListener('mouseenter', function() {
        const tooltip = this.querySelector('.tooltip');
        if (tooltip) {
          tooltip.style.opacity = '1';
        }
      });
      
      card.addEventListener('mouseleave', function() {
        const tooltip = this.querySelector('.tooltip');
        if (tooltip) {
          tooltip.style.opacity = '0';
        }
      });
    });

    // Interview cards click interaction
    document.querySelectorAll('.interview-card').forEach(card => {
      card.addEventListener('click', function() {
        const label = this.querySelector('.interview-label').textContent;
        const count = this.querySelector('.interview-count').textContent;
        
        const message = document.createElement('div');
        message.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(127, 90, 240, 0.95); color: white; padding: 2rem 3rem; border-radius: 16px; font-size: 1.2rem; font-weight: 600; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 10000; text-align: center;';
        message.textContent = `${label} Interviews: ${count}`;
        document.body.appendChild(message);
        
        setTimeout(() => {
          message.remove();
        }, 2000);
      });
    });

    // Legend item interactions
    document.querySelectorAll('.legend-item').forEach(item => {
      item.addEventListener('click', function() {
        const skill = this.querySelector('.legend-text').textContent;
        
        const message = document.createElement('div');
        message.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(127, 90, 240, 0.95); color: white; padding: 2rem 3rem; border-radius: 16px; font-size: 1.1rem; font-weight: 600; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 10000;';
        message.textContent = `Skill: ${skill}`;
        document.body.appendChild(message);
        
        setTimeout(() => {
          message.remove();
        }, 2000);
      });
    });

    // Social links
    document.querySelectorAll('.social-icon').forEach(icon => {
      icon.addEventListener('click', function() {
        const message = document.createElement('div');
        message.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(127, 90, 240, 0.95); color: white; padding: 2rem 3rem; border-radius: 16px; font-size: 1.2rem; font-weight: 600; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 10000;';
        message.textContent = 'Opening social profile...';
        document.body.appendChild(message);
        
        setTimeout(() => {
          message.remove();
        }, 2000);
      });
    });

    async function onConfigChange(config) {
      const customFont = config.font_family || defaultConfig.font_family;
      const baseFontStack = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
      const fontFamily = `${customFont}, ${baseFontStack}`;
      const baseSize = config.font_size || defaultConfig.font_size;
      
      document.body.style.fontFamily = fontFamily;
      document.body.style.fontSize = `${baseSize}px`;
      document.body.style.background = config.background_color || defaultConfig.background_color;
      document.body.style.color = config.text_color || defaultConfig.text_color;

      const profileCard = document.querySelector('.profile-card');
      if (profileCard) {
        profileCard.style.background = `linear-gradient(135deg, ${config.surface_color || defaultConfig.surface_color}, rgba(62, 42, 109, 0.6))`;
      }

      const accentElements = document.querySelectorAll('.badge-role, .skill-tag');
      accentElements.forEach(el => {
        el.style.borderColor = `rgba(${config.accent_color || defaultConfig.accent_color}, 0.4)`;
      });

      document.getElementById('site-name').textContent = config.site_name || defaultConfig.site_name;
      document.getElementById('user-name').textContent = config.user_name || defaultConfig.user_name;
      document.getElementById('profile-full-name').textContent = config.profile_full_name || defaultConfig.profile_full_name;
      document.getElementById('profile-role').textContent = config.profile_role || defaultConfig.profile_role;
      document.getElementById('profile-position').textContent = config.profile_position || defaultConfig.profile_position;
      document.getElementById('profile-location').textContent = config.profile_location || defaultConfig.profile_location;
      document.getElementById('profile-timezone').textContent = config.profile_timezone || defaultConfig.profile_timezone;
      document.getElementById('ability-test-score').textContent = config.ability_test_score || defaultConfig.ability_test_score;
      document.getElementById('availability-score').textContent = config.availability_score || defaultConfig.availability_score;
      document.getElementById('leadership-score').textContent = config.leadership_score || defaultConfig.leadership_score;
      document.getElementById('aspect-score').textContent = config.aspect_score || defaultConfig.aspect_score;
      document.getElementById('interviews-title').textContent = config.interviews_title || defaultConfig.interviews_title;
      document.getElementById('interviews-role').textContent = config.interviews_role || defaultConfig.interviews_role;
      document.getElementById('interviews-all').textContent = config.interviews_all || defaultConfig.interviews_all;
      document.getElementById('interviews-new').textContent = config.interviews_new || defaultConfig.interviews_new;
      document.getElementById('interviews-screening').textContent = config.interviews_screening || defaultConfig.interviews_screening;
      document.getElementById('footer-mission').textContent = config.footer_mission || defaultConfig.footer_mission;

      const profileName = document.querySelector('.profile-name');
      if (profileName) profileName.style.fontSize = `${baseSize * 1.8}px`;
      
      const sectionTitles = document.querySelectorAll('.section-title, .interviews-title');
      sectionTitles.forEach(title => {
        title.style.fontSize = `${baseSize * 1.8}px`;
      });
    }

    function mapToCapabilities(config) {
      return {
        recolorables: [
          {
            get: () => config.background_color || defaultConfig.background_color,
            set: (value) => {
              config.background_color = value;
              window.elementSdk.setConfig({ background_color: value });
            }
          },
          {
            get: () => config.surface_color || defaultConfig.surface_color,
            set: (value) => {
              config.surface_color = value;
              window.elementSdk.setConfig({ surface_color: value });
            }
          },
          {
            get: () => config.text_color || defaultConfig.text_color,
            set: (value) => {
              config.text_color = value;
              window.elementSdk.setConfig({ text_color: value });
            }
          },
          {
            get: () => config.primary_action_color || defaultConfig.primary_action_color,
            set: (value) => {
              config.primary_action_color = value;
              window.elementSdk.setConfig({ primary_action_color: value });
            }
          },
          {
            get: () => config.accent_color || defaultConfig.accent_color,
            set: (value) => {
              config.accent_color = value;
              window.elementSdk.setConfig({ accent_color: value });
            }
          }
        ],
        borderables: [],
        fontEditable: {
          get: () => config.font_family || defaultConfig.font_family,
          set: (value) => {
            config.font_family = value;
            window.elementSdk.setConfig({ font_family: value });
          }
        },
        fontSizeable: {
          get: () => config.font_size || defaultConfig.font_size,
          set: (value) => {
            config.font_size = value;
            window.elementSdk.setConfig({ font_size: value });
          }
        }
      };
    }

    function mapToEditPanelValues(config) {
      return new Map([
        ["site_name", config.site_name || defaultConfig.site_name],
        ["user_name", config.user_name || defaultConfig.user_name],
        ["profile_full_name", config.profile_full_name || defaultConfig.profile_full_name],
        ["profile_role", config.profile_role || defaultConfig.profile_role],
        ["profile_position", config.profile_position || defaultConfig.profile_position],
        ["profile_location", config.profile_location || defaultConfig.profile_location],
        ["profile_timezone", config.profile_timezone || defaultConfig.profile_timezone],
        ["ability_test_score", config.ability_test_score || defaultConfig.ability_test_score],
        ["availability_score", config.availability_score || defaultConfig.availability_score],
        ["leadership_score", config.leadership_score || defaultConfig.leadership_score],
        ["aspect_score", config.aspect_score || defaultConfig.aspect_score],
        ["interviews_title", config.interviews_title || defaultConfig.interviews_title],
        ["interviews_role", config.interviews_role || defaultConfig.interviews_role],
        ["interviews_all", config.interviews_all || defaultConfig.interviews_all],
        ["interviews_new", config.interviews_new || defaultConfig.interviews_new],
        ["interviews_screening", config.interviews_screening || defaultConfig.interviews_screening],
        ["footer_mission", config.footer_mission || defaultConfig.footer_mission]
      ]);
    }

    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange,
        mapToCapabilities,
        mapToEditPanelValues
      });
    }
  </script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9a26329c213a9949',t:'MTc2Mzc5MTEzNC4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>