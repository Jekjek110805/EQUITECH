<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up to EquiTech</title>
  <style>
    /* Global Styles */
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #1a0a33; /* Dark background for the entire page */
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      color: #ffffff;
      overflow: hidden; 
    }

    /* Main Layout Container */
    .login-container {
      display: flex;
      width: 90%; 
      max-width: 1200px; 
      height: 850px; /* FIX: Increased height to fit all fields comfortably */
      background-color: transparent; 
      border-radius: 15px; 
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
      overflow: hidden; 
    }

    /* Left Panel: Image and Text */
    .login-left {
      flex: 1; /* Takes up 50% width */
      background-image: url('prof2.png'); /* <<< Your background image here */
      background-size: cover;
      background-position: center;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-start;
      padding: 3rem;
      position: relative;
      color: #ffffff;
      text-align: left;
    }

    .login-left::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      /* Dark overlay for text readability */
      background: linear-gradient(to right, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.1)); 
      z-index: 1;
    }

    .login-left > * {
      position: relative;
      z-index: 2; 
    }

    .back-arrow {
      position: absolute;
      top: 2rem;
      left: 2rem;
      color: #ffffff;
      font-size: 2rem;
      cursor: pointer;
      z-index: 3;
      text-decoration: none;
    }

    .login-left .logo {
      font-size: 4.5rem;
      font-weight: 800;
      color: #7f5af0;
      margin-bottom: 1rem;
      font-family: verdana;
    }
    
    .login-left h1 {
        font-size: 2.2rem;
        font-weight: 700;
        line-height: 1.4;
        margin: 0;
        max-width: 80%; 
    }

    .login-left .highlight {
        color: #e6d644; 
    }

    /* Right Panel: Form Area */
    .login-right {
      flex: 1; 
      background: transparent; 
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center; 
      border-left: 2px solid #2d1b5e; 
      margin-right: 25px;
    }

    .login-form-content {
        width: 100%;
        max-width: 400px;
        text-align: center;
        background-color: #190f33; 
        padding: 3rem 2rem;
        border-radius: 10px;
        margin-top:0; /* FIX: Removed fixed margin to rely on 'justify-content: center' for perfect vertical alignment */
    }

    .login-right h2 {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
      color: #ffffff;
    }

    .login-right .logo-text {
        font-size: 1.8rem;
        font-weight: 700;
        color: #7f5af0; 
        margin-bottom: 1.5rem;
    }

    .login-right p {
      color: #cccccc;
      margin-bottom: 2rem;
      font-size: 0.95rem;
    }

    /* Form Elements */
    .input-group {
      margin-bottom: 1.2rem; 
      position: relative;
      text-align: left; 
    }

    .input-group label {
        display: block;
        margin-bottom: 0.5rem;
        font-size: 0.9rem;
        color: #cccccc;
    }

    .input-field {
      width: 100%;
      padding: 0.8rem 1.2rem;
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 8px;
      background-color: rgba(255, 255, 255, 0.1);
      color: #ffffff;
      font-size: 1rem;
      outline: none;
      transition: border-color 0.3s, background-color 0.3s;
    }

    .input-field::placeholder {
      color: rgba(255, 255, 255, 0.5);
    }

    .input-field:focus {
      border-color: #7f5af0;
      background-color: rgba(127, 90, 240, 0.15);
    }

    /* Password Toggle Fix */
    .password-toggle {
      position: absolute;
      right: 10px;
      top: 55%; 
      transform: translateY(-50%); 
      color: rgba(255, 255, 255, 0.5);
      cursor: pointer;
      font-size: 1.2rem; 
    }

    .options-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      font-size: 0.9rem;
    }

    .remember-me {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: #cccccc;
    }

    .forgot-password {
      color: #7f5af0;
      text-decoration: none;
      transition: color 0.3s;
    }

    .forgot-password:hover {
      color: #a466ff;
    }

    .sign-in-btn {
      width: 100%;
      padding: 1rem 0;
      background: linear-gradient(to right, #7f5af0, #a466ff); 
      color: #ffffff;
      border: none;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      margin-bottom: 1.5rem;
    }

    .sign-in-btn:hover {
      opacity: 0.9;
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(127, 90, 240, 0.4);
    }

    .or-divider {
      display: flex;
      align-items: center;
      text-align: center;
      color: #cccccc;
      margin-bottom: 1.5rem;
      font-size: 0.9rem;
    }

    .or-divider::before,
    .or-divider::after {
      content: '';
      flex: 1;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .or-divider:not(:empty)::before {
      margin-right: 1em;
    }

    .or-divider:not(:empty)::after {
      margin-left: 1em;
    }

    .social-login-btn {
      width: 100%;
      padding: 0.9rem 0;
      background-color: rgba(255, 255, 255, 0.1);
      color: #ffffff;
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.3s;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.8rem;
    }

    .social-login-btn:hover {
      background-color: rgba(255, 255, 255, 0.15);
      border-color: #7f5af0;
    }

    .social-login-btn img {
      width: 20px;
      height: 20px;
    }

    .signup-link {
      color: #cccccc;
      font-size: 0.9rem;
      margin-top: 1.5rem;
    }

    .signup-link a {
      color: #7f5af0;
      text-decoration: none;
      font-weight: 600;
      transition: color 0.3s;
    }

    .signup-link a:hover {
      color: #a466ff;
    }

    /* Responsive adjustments */
    @media (max-width: 992px) {
      .login-container {
        width: 95%;
        height: auto;
        flex-direction: column;
      }

      .login-left {
        height: 300px; 
        padding: 2rem;
        text-align: center;
        align-items: center;
      }

      .login-left::before {
        background: rgba(0, 0, 0, 0.5); 
      }
      
      .back-arrow {
          top: 1rem;
          left: 1rem;
      }

      .login-left .logo {
          margin-bottom: 0.5rem;
      }

      .login-left h1 {
          font-size: 1.8rem;
          max-width: 90%;
      }

      .login-right {
        padding: 2rem;
        border-left: none; /* Remove border on mobile */
      }

      .login-form-content {
          max-width: none; 
          margin-right: 20px;
      }
    }

    @media (max-width: 576px) {
        .login-left h1 {
            font-size: 1.5rem;
        }
        .login-right h2 {
            font-size: 1.7rem;
        }
        .login-right .logo-text {
            font-size: 1.5rem;
        }
    }

  </style>
 </head>
 <body>
  <div class="login-container">
   <div class="login-left">
    <a href="index.php" class="back-arrow" onclick="history.back()">&#8592;</a>
    <div class="logo">
     EquiTech
    </div>
    <h1>Start your <span class="highlight">equitable</span> career journey today with EquiTech.</h1>
   </div>
   <div class="login-right">
    <div class="login-form-content">
     <h2>Create an Account</h2>
     <div class="logo-text">
      EquiTech
     </div>
     <p>Sign up to start discovering job opportunities</p>
     
     <div class="input-group">
      <label for="email">Email</label>
      <input type="email" id="email" class="input-field" placeholder="Enter your email address">
     </div>

     <div class="input-group">
      <label for="username">Username</label>
      <input type="text" id="username" class="input-field" placeholder="Choose a username">
     </div>
     
     <div class="input-group">
      <label for="password">Password</label>
      <div style="position: relative;">
       <input type="password" id="password" class="input-field" placeholder="Create a password">
       <span class="password-toggle" onclick="togglePasswordVisibility('password')">
        </span>
      </div>
     </div>

     <div class="input-group">
      <label for="confirm-password">Confirm Password</label>
      <div style="position: relative;">
       <input type="password" id="confirm-password" class="input-field" placeholder="Re-enter your password">
       <span class="password-toggle" onclick="togglePasswordVisibility('confirm-password')">
        </span>
      </div>
     </div>
     
     <div class="options-row" style="justify-content: flex-end;"> 
      <a href="#" class="forgot-password">Need Help?</a>
     </div>
     
     <button class="sign-in-btn">Sign up</button>
     
     <div class="or-divider">
      or
     </div>
     
     <button class="social-login-btn">
      <img src="https://img.icons8.com/color/48/000000/google-logo.png" alt="Google icon"> Continue with Google
     </button>
     <button class="social-login-btn">
      <img src="https://img.icons8.com/ios-filled/50/ffffff/github.png" alt="Github icon"> Continue with Github
     </button>
     
     <p class="signup-link">Already have an account? <a href="Loginpage.php">Log in</a></p>
    </div>
   </div>
  </div>
  <script>
    function togglePasswordVisibility(id) {
        const input = document.getElementById(id);
        const toggle = input.nextElementSibling;
        
        if (input.type === "password") {
            input.type = "text";
        } else {
            input.type = "password";
        }
        // Force re-render of the toggle icon's pseudo-content (which displays the eye)
        toggle.style.opacity = 0.99;
        setTimeout(() => {
            toggle.style.opacity = 1;
        }, 10);
    }
  </script>
 </body>
</html>