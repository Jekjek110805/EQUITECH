<?php
// Process login: must run before any output
session_start();
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/utils.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$username = trim((string)($_POST['username'] ?? ''));
$password = $_POST['password'] ?? '';
$remember = isset($_POST['remember']);

// Simple user lookup (from users.php)
$users = get_users();

if (!array_key_exists($username, $users) || !password_verify($password, $users[$username])) {
    // Invalid credentials: keep username as flash so it shows back in the form
    $_SESSION['old_username'] = $username;
    $_SESSION['error'] = 'Invalid username or password.';
    header('Location: index.php');
    exit;
}

// Successful login: clear old flash values so username does not persist after logout
unset($_SESSION['old_username'], $_SESSION['error']);

// Regenerate session id to avoid fixation
session_regenerate_id(true);
$_SESSION['user'] = $username;

// If "remember me" checked, create token and set cookie
if ($remember) {
    $token = create_remember_token($username);
    $options = get_cookie_options($token['expires']);
    $cookieValue = $token['selector'] . ':' . $token['validator'];
    // setcookie with options array (PHP 7.3+)
    setcookie('remember_me', $cookieValue, $options);
}

header('Location: dashboard.php');
exit;