<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EquiTech - Find Your Mentor</title>
  <script src="/_sdk/element_sdk.js"></script>
  <style>
    body {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #190f33;
      color: #ffffff;
      min-height: 100%;
    }

    *, *::before, *::after {
      box-sizing: border-box;
    }

    html {
      height: 100%;
    }

    /* Header */
    header {
      background: linear-gradient(135deg, rgba(25, 15, 51, 0.98), rgba(43, 28, 75, 0.98));
      backdrop-filter: blur(10px);
      padding: 1rem 3rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgba(127, 90, 240, 0.2);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: #ffffff;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    nav {
      display: flex;
      gap: 2.5rem;
      align-items: center;
    }

    nav a {
      color: #cccccc;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s;
      font-size: 0.95rem;
      padding-bottom: 0.25rem;
      border-bottom: 2px solid transparent;
    }

    nav a:hover {
      color: #ffffff;
    }

    .header-right {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }

    .icon-actions {
      display: flex;
      gap: 1rem;
      align-items: center;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: rgba(127, 90, 240, 0.15);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.3s;
      font-size: 1.2rem;
      border: none;
      color: #ffffff;
    }

    .icon-btn:hover {
      background: rgba(127, 90, 240, 0.3);
      transform: scale(1.1);
    }

    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      background: rgba(127, 90, 240, 0.15);
      padding: 0.5rem 1rem;
      border-radius: 25px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .user-profile:hover {
      background: rgba(127, 90, 240, 0.25);
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 0.85rem;
    }

    .user-info {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }

    .user-name {
      font-weight: 600;
      font-size: 0.9rem;
    }

    .view-profile {
      font-size: 0.75rem;
      color: #cccccc;
    }

    /* Hero Section */
    .hero {
      padding: 3rem 3rem 2rem 3rem;
      max-width: 1400px;
      margin: 0 auto;
    }

    .hero-content {
      text-align: center;
      margin-bottom: 2.5rem;
    }

    .hero h1 {
      font-size: 3rem;
      font-weight: 800;
      margin: 0 0 1rem 0;
      color: #ffffff;
      line-height: 1.2;
    }

    .hero-subtitle {
      font-size: 1.1rem;
      color: #cccccc;
      max-width: 800px;
      margin: 0 auto;
      line-height: 1.6;
    }

    /* Filters Section */
    .filters-section {
      background: rgba(43, 28, 75, 0.4);
      border: 1px solid rgba(127, 90, 240, 0.2);
      border-radius: 20px;
      padding: 2rem;
      margin-bottom: 2.5rem;
    }

    .search-row {
      display: grid;
      grid-template-columns: 2fr repeat(5, 1fr);
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .search-input-wrapper {
      position: relative;
    }

    .search-input {
      width: 100%;
      padding: 0.9rem 1.2rem;
      background: rgba(0, 0, 0, 0.3);
      border: 1px solid rgba(127, 90, 240, 0.3);
      border-radius: 12px;
      color: #ffffff;
      font-size: 0.95rem;
      outline: none;
      transition: all 0.3s;
    }

    .search-input:focus {
      border-color: #7f5af0;
      box-shadow: 0 0 0 3px rgba(127, 90, 240, 0.2);
    }

    .search-input::placeholder {
      color: #999999;
    }

    .filter-select {
      width: 100%;
      padding: 0.9rem 1.2rem;
      background: rgba(0, 0, 0, 0.3);
      border: 1px solid rgba(127, 90, 240, 0.3);
      border-radius: 12px;
      color: #ffffff;
      font-size: 0.95rem;
      outline: none;
      cursor: pointer;
      transition: all 0.3s;
    }

    .filter-select:hover {
      border-color: #7f5af0;
    }

    .filter-select option {
      background: #190f33;
      color: #ffffff;
    }

    /* Categories and Actions */
    .categories-actions {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 2rem;
    }

    .category-pills {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .category-pill {
      padding: 0.7rem 1.5rem;
      background: rgba(127, 90, 240, 0.2);
      border: 2px solid rgba(127, 90, 240, 0.4);
      border-radius: 25px;
      color: #ffffff;
      font-weight: 600;
      font-size: 0.9rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .category-pill:hover {
      background: rgba(127, 90, 240, 0.3);
      transform: translateY(-2px);
    }

    .category-pill.active {
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      border-color: #7f5af0;
      box-shadow: 0 4px 16px rgba(127, 90, 240, 0.4);
    }

    .action-buttons {
      display: flex;
      gap: 1rem;
    }

    .action-btn {
      padding: 0.9rem 2rem;
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      border: none;
      border-radius: 25px;
      color: #ffffff;
      font-weight: 600;
      font-size: 0.95rem;
      cursor: pointer;
      transition: all 0.3s;
      white-space: nowrap;
    }

    .action-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(127, 90, 240, 0.5);
    }

    .action-btn.secondary {
      background: rgba(127, 90, 240, 0.2);
      border: 2px solid #7f5af0;
    }

    /* Mentors Section */
    .mentors-section {
      padding: 0 3rem 3rem 3rem;
      max-width: 1400px;
      margin: 0 auto;
      position: relative;
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2.5rem;
    }

    .section-title {
      font-size: 2.2rem;
      font-weight: 700;
      margin: 0;
      color: #ffffff;
    }

    .mentors-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 2rem;
      margin-bottom: 3rem;
    }

    .mentor-card {
      background: linear-gradient(135deg, rgba(43, 28, 75, 0.8), rgba(62, 42, 109, 0.6));
      border: 1px solid rgba(127, 90, 240, 0.3);
      border-radius: 20px;
      padding: 1.5rem;
      transition: all 0.3s;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      opacity: 1;
      transform: scale(1);
    }

    .mentor-card.hidden {
      display: none;
    }

    .mentor-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 12px 40px rgba(127, 90, 240, 0.4);
      border-color: rgba(127, 90, 240, 0.6);
    }

    .mentor-image-wrapper {
      position: relative;
      margin-bottom: 1rem;
    }

    /* REVISED CSS: To handle actual images */
    .mentor-image {
      width: 100%;
      height: 200px;
      border-radius: 12px;
      /* Default background for placeholder/missing image */
      background: linear-gradient(135deg, #4a90e2, #7f5af0); 
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 4rem;
      overflow: hidden;
    }
    
    .mentor-image img {
      width: 100%;
      height: 100%;
      /* Important for fitting images nicely */
      object-fit: cover; 
      display: block;
      border-radius: 12px; /* Ensure image also has rounded corners */
    }

    .new-badge {
      position: absolute;
      top: 10px;
      right: 10px;
      background: #ef4444;
      color: #ffffff;
      padding: 0.3rem 0.8rem;
      border-radius: 20px;
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
    }

    .mentor-info {
      flex: 1;
    }

    .mentor-name {
      font-size: 1.2rem;
      font-weight: 700;
      margin: 0 0 0.5rem 0;
      color: #ffffff;
      text-transform: uppercase;
    }

    .mentor-rating {
      display: flex;
      gap: 0.25rem;
      margin-bottom: 1rem;
    }

    .star {
      color: #ffb833;
      font-size: 1rem;
    }

    .mentor-description {
      font-size: 0.9rem;
      color: #cccccc;
      line-height: 1.5;
      margin-bottom: 1.5rem;
    }

    .mentor-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.75rem;
    }

    .mentor-btn {
      padding: 0.7rem 1rem;
      border: 1px solid rgba(127, 90, 240, 0.5);
      border-radius: 10px;
      font-weight: 600;
      font-size: 0.8rem;
      cursor: pointer;
      transition: all 0.3s;
      text-align: center;
      text-transform: uppercase;
    }

    .mentor-btn.primary {
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      color: #ffffff;
      border: none;
    }

    .mentor-btn.primary:hover {
      box-shadow: 0 4px 16px rgba(127, 90, 240, 0.5);
      transform: translateY(-2px);
    }

    .mentor-btn.secondary {
      background: rgba(127, 90, 240, 0.1);
      color: #ffffff;
    }

    .mentor-btn.secondary:hover {
      background: rgba(127, 90, 240, 0.2);
      border-color: #7f5af0;
    }

    /* See More Button */
    .see-more-container {
      text-align: center;
      margin-top: 3rem;
      opacity: 0;
      transition: opacity 0.5s;
    }

    .see-more-container.visible {
      opacity: 1;
    }

    .see-more-btn {
      padding: 1rem 3rem;
      background: rgba(127, 90, 240, 0.2);
      border: 2px solid #7f5af0;
      border-radius: 30px;
      color: #ffffff;
      font-weight: 600;
      font-size: 1.1rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .see-more-btn:hover {
      background: rgba(127, 90, 240, 0.4);
      transform: translateY(-4px);
      box-shadow: 0 8px 24px rgba(127, 90, 240, 0.4);
    }

    /* Footer */
    footer {
      background: linear-gradient(135deg, #5e5d34, #706e30);
      padding: 4rem 3rem 2rem 3rem;
      margin-top: 4rem;
    }

    .footer-content {
      max-width: 1400px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr;
      gap: 3rem;
      margin-bottom: 2rem;
    }

    .footer-brand {
      max-width: 400px;
    }

    .footer-logo {
      font-size: 1.8rem;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 1rem;
    }

    .footer-mission {
      font-size: 0.95rem;
      color: #cccccc;
      line-height: 1.7;
      margin-bottom: 1.5rem;
    }

    .social-links {
      display: flex;
      gap: 1rem;
    }

    .social-icon {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .social-icon:hover {
      background: rgba(127, 90, 240, 0.4);
      transform: translateY(-4px);
    }

    .footer-column h3 {
      font-size: 1.1rem;
      font-weight: 700;
      margin: 0 0 1.5rem 0;
      color: #ffffff;
    }

    .footer-links {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }

    .footer-links a {
      color: #cccccc;
      text-decoration: none;
      font-size: 0.95rem;
      transition: all 0.3s;
    }

    .footer-links a:hover {
      color: #ffffff;
      padding-left: 0.5rem;
    }

    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding-top: 2rem;
      text-align: center;
      color: #cccccc;
      font-size: 0.9rem;
    }

    /* Responsive */
    @media (max-width: 1200px) {
      .mentors-grid {
        grid-template-columns: repeat(3, 1fr);
      }

      .search-row {
        grid-template-columns: 1fr 1fr;
      }

      .footer-content {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        gap: 1rem;
        padding: 1rem;
      }

      nav {
        flex-wrap: wrap;
        justify-content: center;
        gap: 1rem;
      }

      .hero {
        padding: 2rem 1rem;
      }

      .hero h1 {
        font-size: 2rem;
      }

      .search-row {
        grid-template-columns: 1fr;
      }

      .categories-actions {
        flex-direction: column;
        align-items: stretch;
      }

      .action-buttons {
        flex-direction: column;
      }

      .mentors-section {
        padding: 0 1rem 2rem 1rem;
      }

      .mentors-grid {
        grid-template-columns: 1fr;
      }

      .footer-content {
        grid-template-columns: 1fr;
        gap: 2rem;
      }
    }
  </style>
  <style>@view-transition { navigation: auto; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
  <script src="https://cdn.tailwindcss.com" type="text/javascript"></script>
 </head>
 <body>
  <header>
   <div class="logo" id="site-name">
    EquiTech
   </div>
   <nav><a href="aboutus.php">About us</a> <a href="E-Learning.php">E-Learning</a> <a href="Training.php">Trainings</a> <a href="Findjob.php">Find Job</a> <a href="CV.php">CV Automation</a>
   </nav>
   <div class="header-right">
    <div class="icon-actions"><button class="icon-btn" aria-label="Notifications">🔔</button> <button class="icon-btn" aria-label="Favorites">❤️</button>
    </div>
    <div class="user-profile">
     <div class="user-avatar">
      RJ
     </div>
     <div class="user-info">
  <div class="user-name" id="user-name">
       RIEL JAKE E.

       </a>
      </div>
      <div class="view-profile">
       View profile
      </div>
     </div>
    </div>
   </div>
  </header>
  <main>
   <section class="hero">
    <div class="hero-content">
     <h1 id="hero-title">Our Mentors</h1>
     <p class="hero-subtitle" id="hero-subtitle">We Already have 1000+ mentors with us. We assure you will able to find here someone who can help you!</p>
    </div>
    <div class="filters-section">
     <div class="search-row">
      <div class="search-input-wrapper"><input type="text" class="search-input" id="mentor-search" placeholder="Search Mentor's Job Position ">
      </div><select class="filter-select"> <option>Specify</option> <option>Graphics Design</option> <option>Web Development</option> <option>Mobile Development</option> </select> <select class="filter-select"> <option>Work Experience</option> <option>0-2 years</option> <option>3-5 years</option> <option>5+ years</option> </select> <select class="filter-select"> <option>Consultation</option> <option>1-on-1</option> <option>Group</option> <option>Online</option> </select> <select class="filter-select"> <option>Rating</option> <option>5 Stars</option> <option>4+ Stars</option> <option>3+ Stars</option> </select> <select class="filter-select"> <option>Select Date</option> <option>This Week</option> <option>This Month</option> <option>Custom</option> </select>
     </div>
     <div class="categories-actions">
      <div class="category-pills"><button class="category-pill active" data-category="all">All Mentors</button> <button class="category-pill" data-category="developer">Developer</button> <button class="category-pill" data-category="tester">Tester</button> <button class="category-pill" data-category="designer">Designer</button> <button class="category-pill" data-category="database">Database Analyst</button>
      </div>
      <div class="action-buttons"><button class="action-btn" id="apply-mentor-btn">Apply as Mentor</button> <button class="action-btn secondary" id="apply-student-btn">Apply as Student</button>
      </div>
     </div>
    </div>
   </section>
   <section class="mentors-section">
    <div class="section-header">
     <h2 class="section-title" id="qualified-title">Qualified Mentors</h2>
    </div>
    <div class="mentors-grid" id="mentors-grid"><div class="mentor-card" data-category="designer">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/736x/5f/cb/0a/5fcb0a5578d81bba2917013c511cc247.jpg" alt="Mentor Joanna's photo" onerror="this.outerHTML='👩‍🎨'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR JOANNA</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Mentor Joanna is a Graphics Design teacher for more than 5yrs. She work qualify of websites.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="developer">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/736x/bd/c6/24/bdc6247d1c8ebafd95db73f665adabd4.jpg" alt="Mentor Lou's photo" onerror="this.outerHTML='👨‍💻'">
       </div><span class="new-badge">NEW</span>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR LOU</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Senior Full Stack Developer with expertise in React, Node.js, and cloud architecture. 8+ years experience.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="tester">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/1200x/32/ea/e9/32eae9f53b8c37d72b8864b93b802c29.jpg" alt="Mentor Harold's photo" onerror="this.outerHTML='👨‍🔬'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR HAROLD</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">QA Expert specializing in automation testing, CI/CD pipelines, and quality assurance best practices.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="database">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/1200x/cc/27/8c/cc278c2257f2f2c44fbed61e7b3d4d7f.jpg" alt="Mentor AA&amp;A's photo" onerror="this.outerHTML='👩‍💼'">
       </div><span class="new-badge">NEW</span>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR AA&amp;A</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Database Administrator with 10+ years in SQL, MongoDB, and database optimization for enterprise systems.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="designer">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/736x/9b/e8/41/9be8413c3017f7f7921c66bd031d4931.jpg" alt="Mentor Alex's photo" onerror="this.outerHTML='👨‍🎨'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR ALEX</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">UX/UI Designer passionate about creating intuitive user experiences. Adobe XD and Figma specialist.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="developer">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/1200x/62/71/fb/6271fba2f6596a96bf200d5ba86452e6.jpg" alt="Mentor Sarah's photo" onerror="this.outerHTML='👩‍💻'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR SARAH</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Mobile App Developer specializing in iOS and Android. Swift, Kotlin, and Flutter expert with 6 years experience.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="tester">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/1200x/b7/37/64/b737644435187ebdb037e574e94bf35d.jpg" alt="Mentor Mike's photo" onerror="this.outerHTML='👨‍🔧'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR MIKE</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Test Automation Engineer with expertise in Selenium, Cypress, and performance testing frameworks.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="database">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/1200x/ec/04/e4/ec04e4bc32b966c32c0de02dba4291ca.jpg" alt="Mentor Emma's photo" onerror="this.outerHTML='👩‍🏫'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR EMMA</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Data Architect specializing in PostgreSQL, MySQL, and cloud databases. Expert in data modeling and optimization.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="designer">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/736x/3a/7a/54/3a7a543e15be6872dc2d6437dc1cbe51.jpg" alt="Mentor David's photo" onerror="this.outerHTML='👨‍🎤'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR DAVID</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Brand Designer with focus on visual identity, logo design, and marketing materials. 7+ years in the industry.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="developer">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/1200x/5e/96/a8/5e96a88d077ba4ca826d15e959043acb.jpg" alt="Mentor Lisa's photo" onerror="this.outerHTML='👩‍🚀'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR LISA</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">DevOps Engineer with deep knowledge in Kubernetes, Docker, AWS, and infrastructure as code practices.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="tester">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/736x/5b/07/8c/5b078cdecc9adbc186a7aafb0766b080.jpg" alt="Mentor James's photo" onerror="this.outerHTML='👨‍🏫'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR JAMES</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Security Testing Specialist focused on penetration testing, vulnerability assessment, and secure coding practices.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div><div class="mentor-card" data-category="database">
      <div class="mentor-image-wrapper">
       <div class="mentor-image">
        <img src="https://i.pinimg.com/736x/e1/ed/55/e1ed55aba1e713ca45618c432cef0098.jpg" alt="Mentor Rachel's photo" onerror="this.outerHTML='👩‍🔬'">
       </div>
      </div>
      <div class="mentor-info">
       <h3 class="mentor-name">MENTOR RACHEL</h3>
       <div class="mentor-rating"><span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span> <span class="star">★</span>
       </div>
       <p class="mentor-description">Data Scientist with expertise in SQL, NoSQL, and big data technologies. Analytics and BI specialist.</p>
      </div>
      <div class="mentor-actions"><button class="mentor-btn primary">GET ASSIGN</button> <button class="mentor-btn secondary">VIEW PROFILE</button>
      </div>
     </div>
    </div>
    <div class="see-more-container" id="see-more-container"><button class="see-more-btn" id="see-more-btn">See More</button>
    </div>
   </section>
  </main>
  <footer style="background: #0D0021; border-top: 1px solid #2D1B4E; padding: 3rem 0 2rem;">
   <div style="max-width: 1400px; margin: 0 auto; padding: 0 2rem;">
    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 3rem; margin-bottom: 3rem;"><div>
      <div style="font-size: 1.75rem; font-weight: 700; margin-bottom: 1rem;"><span style="color: #ffffff;" id="footer-brand-name">EquiTech</span>
      </div>
      <p style="color: #9CA3AF; line-height: 1.6; margin-bottom: 1.5rem;" id="footer-tagline-display">We have right mentors for any job. EquiTech will help you learn to code and help you to connect with them easily and effectively.</p><div style="display: flex; gap: 1rem;">
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
       </div>
      </div>
     </div><div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Product</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Features</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Pricing</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Integrations</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Changelog</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div><div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Resources</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Documentation</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Tutorials</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Blogs</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Support</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">FAQ</a></li>
      </ul>
     </div><div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Company</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">About</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Careers</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Contact</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Partners</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div>
    </div><div style="border-top: 1px solid #2D1B4E; padding-top: 2rem; text-align: center;">
     <p style="color: #6B7280; font-size: 0.9rem; margin: 0;">© 2022 EquiTech. All rights reserved.</p>
    </div>
   </div>
  </footer>
  <script>

    // Category filtering functionality
    let currentCategory = 'all';
    
    const categoryPills = document.querySelectorAll('.category-pill');
    const mentorCards = document.querySelectorAll('.mentor-card');
    const seeMoreContainer = document.getElementById('see-more-container');

    categoryPills.forEach(pill => {
      pill.addEventListener('click', function() {
        // Remove active class from all pills
        categoryPills.forEach(p => p.classList.remove('active'));
        
        // Add active class to clicked pill
        this.classList.add('active');
        
        // Get selected category
        currentCategory = this.dataset.category;
        
        // Filter mentor cards
        filterMentors(currentCategory);
      });
    });

    function filterMentors(category) {
      mentorCards.forEach(card => {
        if (category === 'all') {
          card.classList.remove('hidden');
        } else {
          if (card.dataset.category === category) {
            card.classList.remove('hidden');
          } else {
            card.classList.add('hidden');
          }
        }
      });
    }

    // Search functionality
    const searchInput = document.getElementById('mentor-search');
    searchInput.addEventListener('input', function(e) {
      const searchTerm = e.target.value.toLowerCase();
      
      mentorCards.forEach(card => {
        const mentorName = card.querySelector('.mentor-name').textContent.toLowerCase();
        const mentorDesc = card.querySelector('.mentor-description').textContent.toLowerCase();
        
        if (mentorName.includes(searchTerm) || mentorDesc.includes(searchTerm)) {
          if (currentCategory === 'all' || card.dataset.category === currentCategory) {
            card.classList.remove('hidden');
          }
        } else {
          card.classList.add('hidden');
        }
      });
    });

    // See More button scroll effect
    let seeMoreVisible = false;
    
    window.addEventListener('scroll', function() {
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;
      
      if (scrollPosition > windowHeight * 0.5 && !seeMoreVisible) {
        seeMoreContainer.classList.add('visible');
        seeMoreVisible = true;
      }
    });

    document.getElementById('see-more-btn').addEventListener('click', function() {
      const message = document.createElement('div');
      message.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(127, 90, 240, 0.95); color: white; padding: 2rem 3rem; border-radius: 16px; font-size: 1.2rem; font-weight: 600; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 10000;';
      message.textContent = 'Loading more mentors...';
      document.body.appendChild(message);
      
      setTimeout(() => {
        message.remove();
      }, 2000);
    });

    // Action buttons
    document.getElementById('apply-mentor-btn').addEventListener('click', function() {
      const message = document.createElement('div');
      message.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(127, 90, 240, 0.95); color: white; padding: 2rem 3rem; border-radius: 16px; font-size: 1.2rem; font-weight: 600; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 10000;';
      message.textContent = 'Opening mentor application...';
      document.body.appendChild(message);
      
      setTimeout(() => {
        message.remove();
      }, 2000);
    });

    document.getElementById('apply-student-btn').addEventListener('click', function() {
      const message = document.createElement('div');
      message.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(127, 90, 240, 0.95); color: white; padding: 2rem 3rem; border-radius: 16px; font-size: 1.2rem; font-weight: 600; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 10000;';
      message.textContent = 'Opening student application...';
      document.body.appendChild(message);
      
      setTimeout(() => {
        message.remove();
      }, 2000);
    });


    async function onConfigChange(config) {
      const customFont = config.font_family || defaultConfig.font_family;
      const baseFontStack = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
      const fontFamily = `${customFont}, ${baseFontStack}`;
      const baseSize = config.font_size || defaultConfig.font_size;
      
      document.body.style.fontFamily = fontFamily;
      document.body.style.fontSize = `${baseSize}px`;
      document.body.style.background = config.background_color || defaultConfig.background_color;
      document.body.style.color = config.text_color || defaultConfig.text_color;

      document.getElementById('site-name').textContent = config.site_name || defaultConfig.site_name;
      document.getElementById('user-name').textContent = config.user_name || defaultConfig.user_name;
      document.getElementById('hero-title').textContent = config.hero_title || defaultConfig.hero_title;
      document.getElementById('hero-subtitle').textContent = config.hero_subtitle || defaultConfig.hero_subtitle;
      document.getElementById('mentor-search').placeholder = config.search_placeholder || defaultConfig.search_placeholder;
      document.getElementById('apply-mentor-btn').textContent = config.apply_mentor_btn || defaultConfig.apply_mentor_btn;
      document.getElementById('apply-student-btn').textContent = config.apply_student_btn || defaultConfig.apply_student_btn;
      document.getElementById('qualified-title').textContent = config.qualified_title || defaultConfig.qualified_title;
      document.getElementById('see-more-btn').textContent = config.see_more_text || defaultConfig.see_more_text;
      document.getElementById('footer-mission').textContent = config.footer_mission || defaultConfig.footer_mission;

      const heroTitle = document.querySelector('.hero h1');
      if (heroTitle) heroTitle.style.fontSize = `${baseSize * 3}px`;
      
      const heroSubtitle = document.querySelector('.hero-subtitle');
      if (heroSubtitle) heroSubtitle.style.fontSize = `${baseSize * 1.1}px`;
      
      const sectionTitle = document.querySelector('.section-title');
      if (sectionTitle) sectionTitle.style.fontSize = `${baseSize * 2.2}px`;
    }

    function mapToCapabilities(config) {
      return {
        recolorables: [
          {
            get: () => config.background_color || defaultConfig.background_color,
            set: (value) => {
              config.background_color = value;
              window.elementSdk.setConfig({ background_color: value });
            }
          },
          {
            get: () => config.surface_color || defaultConfig.surface_color,
            set: (value) => {
              config.surface_color = value;
              window.elementSdk.setConfig({ surface_color: value });
            }
          },
          {
            get: () => config.text_color || defaultConfig.text_color,
            set: (value) => {
              config.text_color = value;
              window.elementSdk.setConfig({ text_color: value });
            }
          },
          {
            get: () => config.primary_action_color || defaultConfig.primary_action_color,
            set: (value) => {
              config.primary_action_color = value;
              window.elementSdk.setConfig({ primary_action_color: value });
            }
          },
          {
            get: () => config.accent_color || defaultConfig.accent_color,
            set: (value) => {
              config.accent_color = value;
              window.elementSdk.setConfig({ accent_color: value });
            }
          }
        ],
        borderables: [],
        fontEditable: {
          get: () => config.font_family || defaultConfig.font_family,
          set: (value) => {
            config.font_family = value;
            window.elementSdk.setConfig({ font_family: value });
          }
        },
        fontSizeable: {
          get: () => config.font_size || defaultConfig.font_size,
          set: (value) => {
            config.font_size = value;
            window.elementSdk.setConfig({ font_size: value });
          }
        }
      };
    }

    function mapToEditPanelValues(config) {
      return new Map([
        ["site_name", config.site_name || defaultConfig.site_name],
        ["user_name", config.user_name || defaultConfig.user_name],
        ["hero_title", config.hero_title || defaultConfig.hero_title],
        ["hero_subtitle", config.hero_subtitle || defaultConfig.hero_subtitle],
        ["search_placeholder", config.search_placeholder || defaultConfig.search_placeholder],
        ["apply_mentor_btn", config.apply_mentor_btn || defaultConfig.apply_mentor_btn],
        ["apply_student_btn", config.apply_student_btn || defaultConfig.apply_student_btn],
        ["qualified_title", config.qualified_title || defaultConfig.qualified_title],
        ["see_more_text", config.see_more_text || defaultConfig.see_more_text],
        ["footer_mission", config.footer_mission || defaultConfig.footer_mission]
      ]);
    }

    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange,
        mapToCapabilities,
        mapToEditPanelValues
      });
    }
  </script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9a26461040b10441',t:'MTc2Mzc5MTkzMS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>