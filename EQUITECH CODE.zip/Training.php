<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EquiTech - Trainings</title>
  <script src="/_sdk/element_sdk.js"></script>
  <style>
    body {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #190f33;
      color: #ffffff;

      min-height: 100%;
    }

    *, *::before, *::after {
      box-sizing: border-box;
    }

    html {
      height: 100%;
    }

    /* Header */
    header {
      background: linear-gradient(135deg, rgba(25, 15, 51, 0.98), rgba(43, 28, 75, 0.98));
      backdrop-filter: blur(10px);
      padding: 1rem 3rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgba(127, 90, 240, 0.2);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: #ffffff;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    nav {
      display: flex;
      gap: 2.5rem;
      align-items: center;
    }

    nav a {
      color: #cccccc;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s;
      font-size: 0.95rem;
      padding-bottom: 0.25rem;
      border-bottom: 2px solid transparent;
      position: relative;
    }

    nav a:hover {
      color: #ffffff;
    }

    nav a.active {
      color: #ffffff;
      border-bottom: 2px solid rgba(127, 90, 240, 0.6);
    }

    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      background: rgba(127, 90, 240, 0.15);
      padding: 0.5rem 1rem;
      border-radius: 25px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .user-profile:hover {
      background: rgba(127, 90, 240, 0.25);
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 0.85rem;
    }

    .user-info {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }

    .user-name {
      font-weight: 600;
      font-size: 0.9rem;
    }

    .view-profile {
      font-size: 0.75rem;
      color: #cccccc;
    }

    /* Hero Section */
    .hero {
      min-height: calc(100% - 300px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 4rem 3rem;
      position: relative;
      overflow: hidden;
    }

    .hero-background {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(135deg, rgba(25, 15, 51, 0.85), rgba(43, 28, 75, 0.85)), 
                  url('Prof.png" viewBox="0 0 1200 800"><rect fill="%23190f33" width="1200" height="800"/><g opacity="0.3"><circle cx="900" cy="400" r="200" fill="%237f5af0"/><circle cx="300" cy="600" r="150" fill="%235236ad"/></g></svg>');
      background-size: cover;
      background-position: center;
      z-index: 0;
    }



    .hero-content {
      max-width: 1400px;
      width: 100%;
      position: relative;
      z-index: 1;
      text-align: center;
        background-image: 
                  url('Prof.png" viewBox="0 0 1200 800"><rect fill="%23190f33" width="1200" height="800"/><g opacity="0.3"><circle cx="900" cy="400" r="200" fill="%237f5af0"/><circle cx="300" cy="600" r="150" fill="%235236ad"/></g></svg>');
      background-size: cover;
      background-position: center;
      z-index: 0;
    }

    .hero h1 {
      font-size: 4rem;
      font-weight: 800;
      margin: 0 0 2rem 0;
      line-height: 1.2;
      color: #ffffff;
    }

    .hero-highlight {
      background: linear-gradient(135deg, #a466ff, #7f5af0);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      display: inline;
    }

    .hero-description {
      font-size: 1.25rem;
      color: #cccccc;
      max-width: 800px;
      margin: 0 auto 3rem auto;
      line-height: 1.8;
    }

    .hero-buttons {
      display: flex;
      gap: 1.5rem;
      justify-content: center;
      align-items: center;
      margin-bottom: 2rem;
      flex-wrap: wrap;
    }

    .hero-btn {
      padding: 1.1rem 3rem;
      border-radius: 30px;
      font-weight: 600;
      font-size: 1.05rem;
      cursor: pointer;
      transition: all 0.3s;
      border: none;
      white-space: nowrap;
      position: relative;
      overflow: hidden;
      text-decoration: none;
      display: inline-block;
    }

    .hero-btn::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.2);
      transform: translate(-50%, -50%);
      transition: width 0.6s, height 0.6s;
    }

    .hero-btn:hover::before {
      width: 300px;
      height: 300px;
    }

    .hero-btn span {
      position: relative;
      z-index: 1;
    }

    .hero-btn.primary {
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      color: #ffffff;
    }

    .hero-btn.primary:hover {
      transform: translateY(-4px);
      box-shadow: 0 12px 32px rgba(127, 90, 240, 0.6);
    }

    .hero-btn.secondary {
      background: transparent;
      border: 2px solid #7f5af0;
      color: #ffffff;
    }

    .hero-btn.secondary:hover {
      background: rgba(127, 90, 240, 0.2);
      transform: translateY(-4px);
      box-shadow: 0 12px 32px rgba(127, 90, 240, 0.4);
    }

    .hero-apply-text {
      font-size: 1rem;
      color: #cccccc;
      text-align: center;
    }

    .hero-apply-text a {
      color: #7f5af0;
      text-decoration: none;
      font-weight: 600;
      transition: all 0.3s;
      border-bottom: 2px solid transparent;
    }

    .hero-apply-text a:hover {
      color: #a466ff;
      border-bottom: 2px solid #a466ff;
    }

    /* Professional figures representation */
    .hero-figures {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 0;
    }

    .figure {
      position: absolute;
      font-size: 15rem;
      opacity: 0.1;
      filter: blur(2px);
    }

    .figure.left {
      bottom: -5%;
      left: 5%;
      transform: rotate(-5deg);
    }

    .figure.right {
      bottom: -5%;
      right: 5%;
      transform: rotate(5deg);
    }

    /* Footer */
    footer {
      background: #0D0021;
      padding: 4rem 3rem 2rem 3rem;
      margin-top: 4rem;
    }

    .footer-content {
      max-width: 1400px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr;
      gap: 3rem;
      margin-bottom: 2rem;
    }

    .footer-brand {
      max-width: 400px;
    }

    .footer-logo {
      font-size: 1.8rem;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 1rem;
    }

    .footer-mission {
      font-size: 0.95rem;
      color: #cccccc;
      line-height: 1.7;
      margin-bottom: 1.5rem;
    }

    .social-links {
      display: flex;
      gap: 1rem;
    }

    .social-icon {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .social-icon:hover {
      background: rgba(127, 90, 240, 0.4);
      transform: translateY(-4px);
    }

    .footer-column h3 {
      font-size: 1.1rem;
      font-weight: 700;
      margin: 0 0 1.5rem 0;
      color: #ffffff;
    }

    .footer-links {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }

    .footer-links a {
      color: #cccccc;
      text-decoration: none;
      font-size: 0.95rem;
      transition: all 0.3s;
    }

    .footer-links a:hover {
      color: #ffffff;
      padding-left: 0.5rem;
    }

    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding-top: 2rem;
      text-align: center;
      color: #cccccc;
      font-size: 0.9rem;
    }

    /* Responsive */
    @media (max-width: 1200px) {
      .footer-content {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        gap: 1rem;
        padding: 1rem;
      }

      nav {
        flex-wrap: wrap;
        justify-content: center;
        gap: 1rem;
      }

      .hero {
        padding: 3rem 1.5rem;
          background-image: 
                  url('Prof.png" viewBox="0 0 1200 800"><rect fill="%23190f33" width="1200" height="800"/><g opacity="0.3"><circle cx="900" cy="400" r="200" fill="%237f5af0"/><circle cx="300" cy="600" r="150" fill="%235236ad"/></g></svg>');
      background-size: cover;
      background-position: center;
      z-index: 0;
        min-height: auto;
      }

      .hero h1 {
        font-size: 2.5rem;
      }

      .hero-description {
        font-size: 1.1rem;
      }

      .hero-buttons {
        flex-direction: column;
        gap: 1rem;
      }

      .hero-btn {
        width: 100%;
        max-width: 300px;
      }

      .figure {
        font-size: 8rem;
      }

      .footer-content {
        grid-template-columns: 1fr;
        gap: 2rem;
      }
    }

    /* Animation for page load */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .hero-content > * {
      animation: fadeInUp 0.8s ease-out forwards;
    }

    .hero-content h1 {
      animation-delay: 0.1s;
    }

    .hero-content .hero-description {
      animation-delay: 0.3s;
    }

    .hero-content .hero-buttons {
      animation-delay: 0.5s;
    }

    .hero-content .hero-apply-text {
      animation-delay: 0.7s;
    }
  </style>
  <style>@view-transition { navigation: auto; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
  <script src="https://cdn.tailwindcss.com" type="text/javascript"></script>
 </head>
 <body>
  <header>
    <div class="logo" id="site-name">
      EquiTech
    </div>
    <nav>
      <a href="aboutus.php">About us</a>
      <a href="E-Learning.php">E-Learning</a>
      <a href="Training.php" class="active">Trainings</a>
      <a href="FindJob.php">Find Job</a>
      <a href="CV.php">CV Automation</a>
    </nav>
    <div class="user-profile">
      <div class="user-avatar">
        H
      </div>
      <div class="user-info">
        <div class="user-name" id="user-name">
          RIEL JAKE E.
        </div>
        <div class="view-profile">
          View profile
        </div>
      </div>
    </div>
  </header>
  <main>
    <section class="hero">
      <div class="hero-background"></div>
      <div class="hero-figures">
        <div class="figure left">
          
        </div>
        <div class="figure right">
          
        </div>
      </div>
      <div class="hero-content">
        <h1>
          <span id="hero-title-part1">Connect with EquiTech</span>
          <span class="hero-highlight" id="hero-title-highlight">expert mentors</span>
          <span id="hero-title-part2">for your next project</span>
        </h1>
        <p class="hero-description" id="hero-description">We have right mentors for any job. EquiTech will find you right mentor and help you to connect with them easily and effectively.</p>
        <div class="hero-buttons">
          <a href="Mentor.php" class="hero-btn primary" id="find-mentors-btn">
            <span id="find-mentors-text">Find Mentors</span>
          </a>
          <a href="E-Learning.php" class="hero-btn secondary" id="all-courses-btn">
            <span id="all-courses-text">All courses</span>
          </a>
        </div>
        <p class="hero-apply-text">
          <span id="apply-mentor-text">You also apply as a mentor! Visit us:</span>
          <a href="#" id="mentor-website-link">www.EquiTech.mentor.com</a>
        </p>
      </div>
    </section>
  </main>
 <footer style="background: #0D0021; border-top: 1px solid #2D1B4E; padding: 3rem 0 2rem;">
   <div style="max-width: 1400px; margin: 0 auto; padding: 0 2rem;">
    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 3rem; margin-bottom: 3rem;"><!-- Company Info -->
     <div>
      <div style="font-size: 1.75rem; font-weight: 700; margin-bottom: 1rem;"><span style="color: #ffffff;" id="footer-brand-name">EquiTech</span>
      </div>
      <p style="color: #9CA3AF; line-height: 1.6; margin-bottom: 1.5rem;" id="footer-tagline-display">We have right mentors for any job. EquiTech will help you learn to code and help you to connect with them easily and effectively.</p><!-- Social Icons -->
      <div style="display: flex; gap: 1rem;">
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
       </div>
      </div>
     </div><!-- Product -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Product</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Features</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Pricing</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Integrations</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Changelog</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div><!-- Resources -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Resources</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Documentation</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Tutorials</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Blogs</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Support</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">FAQ</a></li>
      </ul>
     </div><!-- Company -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Company</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">About</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Careers</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Contact</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Partners</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div>
    </div><!-- Copyright -->
    <div style="border-top: 1px solid #2D1B4E; padding-top: 2rem; text-align: center;">
     <p style="color: #6B7280; font-size: 0.9rem; margin: 0;">© 2022 EquiTech. All rights reserved.</p>
    </div>
   </div>
  </footer>
  </body>
  <script>
    const defaultConfig = {
      site_name: "💼 EquiTech",
      user_name: "Hiccup H.",
      hero_title_part1: "Connect with EquiTech ",
      hero_title_highlight: "expert mentors",
      hero_title_part2: " for your next project",
      hero_description: "We have right mentors for any job. EquiTech will find you right mentor and help you to connect with them easily and effectively.",
      find_mentors_btn: "Find Mentors",
      all_courses_btn: "All courses",
      apply_mentor_text: "You also apply as a mentor! Visit us: ",
      mentor_website: "www.EquiTech.mentor.com",
      footer_mission: "We have right mentors for any job. EquiTech will find you right mentor and help you to connect with them easily and effectively",
      background_color: "#190f33",
      surface_color: "rgba(43, 28, 75, 0.8)",
      text_color: "#ffffff",
      primary_action_color: "#7f5af0",
      accent_color: "#a466ff",
      font_family: "sans-serif",
      font_size: 16
    };

    // Button interactions
    document.getElementById('mentor-website-link').addEventListener('click', function(e) {
      e.preventDefault();
      createNotification('Opening mentor application portal...');
    });

    // Social icons
    document.querySelectorAll('.social-icon').forEach(icon => {
      icon.addEventListener('click', function() {
        createNotification('Opening social profile...');
      });
    });

    // Footer links
    document.querySelectorAll('.footer-links a').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const linkText = this.textContent;
        createNotification(`Navigating to ${linkText}...`);
      });
    });

    // User profile
    document.querySelector('.user-profile').addEventListener('click', function() {
      createNotification('Opening user profile...');
    });

    // Notification helper function
    function createNotification(message) {
      const notification = document.createElement('div');
      notification.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(127, 90, 240, 0.95); color: white; padding: 2rem 3rem; border-radius: 16px; font-size: 1.2rem; font-weight: 600; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 10000; animation: fadeInUp 0.3s ease-out;';
      notification.textContent = message;
      document.body.appendChild(notification);
      
      setTimeout(() => {
        notification.style.animation = 'fadeInUp 0.3s ease-out reverse';
        setTimeout(() => {
          notification.remove();
        }, 300);
      }, 2000);
    }

    // Enhanced hover effect for buttons with ripple animation
    document.querySelectorAll('.hero-btn').forEach(btn => {
      btn.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        const rect = this.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;
        
        ripple.style.cssText = `
          position: absolute;
          width: ${size}px;
          height: ${size}px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.5);
          left: ${x}px;
          top: ${y}px;
          transform: scale(0);
          animation: ripple 0.6s ease-out;
          pointer-events: none;
        `;
        
        this.appendChild(ripple);
        
        setTimeout(() => {
          ripple.remove();
        }, 600);
      });
    });

    // Add ripple animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes ripple {
        to {
          transform: scale(4);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);

    // SDK Configuration
    async function onConfigChange(config) {
      const customFont = config.font_family || defaultConfig.font_family;
      const baseFontStack = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
      const fontFamily = `${customFont}, ${baseFontStack}`;
      const baseSize = config.font_size || defaultConfig.font_size;
      
      document.body.style.fontFamily = fontFamily;
      document.body.style.fontSize = `${baseSize}px`;
      document.body.style.background = config.background_color || defaultConfig.background_color;
      document.body.style.color = config.text_color || defaultConfig.text_color;

      // Update text content
      document.getElementById('site-name').textContent = config.site_name || defaultConfig.site_name;
      document.getElementById('user-name').textContent = config.user_name || defaultConfig.user_name;
      document.getElementById('hero-title-part1').textContent = config.hero_title_part1 || defaultConfig.hero_title_part1;
      document.getElementById('hero-title-highlight').textContent = config.hero_title_highlight || defaultConfig.hero_title_highlight;
      document.getElementById('hero-title-part2').textContent = config.hero_title_part2 || defaultConfig.hero_title_part2;
      document.getElementById('hero-description').textContent = config.hero_description || defaultConfig.hero_description;
      document.getElementById('find-mentors-text').textContent = config.find_mentors_btn || defaultConfig.find_mentors_btn;
      document.getElementById('all-courses-text').textContent = config.all_courses_btn || defaultConfig.all_courses_btn;
      document.getElementById('apply-mentor-text').textContent = config.apply_mentor_text || defaultConfig.apply_mentor_text;
      document.getElementById('mentor-website-link').textContent = config.mentor_website || defaultConfig.mentor_website;
      document.getElementById('footer-mission').textContent = config.footer_mission || defaultConfig.footer_mission;

      // Update font sizes
      const heroTitle = document.querySelector('.hero h1');
      if (heroTitle) heroTitle.style.fontSize = `${baseSize * 4}px`;
      
      const heroDescription = document.querySelector('.hero-description');
      if (heroDescription) heroDescription.style.fontSize = `${baseSize * 1.25}px`;
      
      // Update colors
      const heroHighlight = document.querySelector('.hero-highlight');
      if (heroHighlight) {
        const accentColor = config.accent_color || defaultConfig.accent_color;
        const primaryColor = config.primary_action_color || defaultConfig.primary_action_color;
        heroHighlight.style.background = `linear-gradient(135deg, ${accentColor}, ${primaryColor})`;
        heroHighlight.style.webkitBackgroundClip = 'text';
        heroHighlight.style.webkitTextFillColor = 'transparent';
        heroHighlight.style.backgroundClip = 'text';
      }

      const primaryButtons = document.querySelectorAll('.hero-btn.primary');
      primaryButtons.forEach(btn => {
        const primaryColor = config.primary_action_color || defaultConfig.primary_action_color;
        btn.style.background = `linear-gradient(135deg, ${primaryColor}, #5236ad)`;
      });

      const secondaryButtons = document.querySelectorAll('.hero-btn.secondary');
      secondaryButtons.forEach(btn => {
        const primaryColor = config.primary_action_color || defaultConfig.primary_action_color;
        btn.style.borderColor = primaryColor;
      });

      const links = document.querySelectorAll('.hero-apply-text a');
      links.forEach(link => {
        const primaryColor = config.primary_action_color || defaultConfig.primary_action_color;
        link.style.color = primaryColor;
      });
    }

    function mapToCapabilities(config) {
      return {
        recolorables: [
          {
            get: () => config.background_color || defaultConfig.background_color,
            set: (value) => {
              config.background_color = value;
              window.elementSdk.setConfig({ background_color: value });
            }
          },
          {
            get: () => config.surface_color || defaultConfig.surface_color,
            set: (value) => {
              config.surface_color = value;
              window.elementSdk.setConfig({ surface_color: value });
            }
          },
          {
            get: () => config.text_color || defaultConfig.text_color,
            set: (value) => {
              config.text_color = value;
              window.elementSdk.setConfig({ text_color: value });
            }
          },
          {
            get: () => config.primary_action_color || defaultConfig.primary_action_color,
            set: (value) => {
              config.primary_action_color = value;
              window.elementSdk.setConfig({ primary_action_color: value });
            }
          },
          {
            get: () => config.accent_color || defaultConfig.accent_color,
            set: (value) => {
              config.accent_color = value;
              window.elementSdk.setConfig({ accent_color: value });
            }
          }
        ],
        borderables: [],
        fontEditable: {
          get: () => config.font_family || defaultConfig.font_family,
          set: (value) => {
            config.font_family = value;
            window.elementSdk.setConfig({ font_family: value });
          }
        },
        fontSizeable: {
          get: () => config.font_size || defaultConfig.font_size,
          set: (value) => {
            config.font_size = value;
            window.elementSdk.setConfig({ font_size: value });
          }
        }
      };
    }

    function mapToEditPanelValues(config) {
      return new Map([
        ["site_name", config.site_name || defaultConfig.site_name],
        ["user_name", config.user_name || defaultConfig.user_name],
        ["hero_title_part1", config.hero_title_part1 || defaultConfig.hero_title_part1],
        ["hero_title_highlight", config.hero_title_highlight || defaultConfig.hero_title_highlight],
        ["hero_title_part2", config.hero_title_part2 || defaultConfig.hero_title_part2],
        ["hero_description", config.hero_description || defaultConfig.hero_description],
        ["find_mentors_btn", config.find_mentors_btn || defaultConfig.find_mentors_btn],
        ["all_courses_btn", config.all_courses_btn || defaultConfig.all_courses_btn],
        ["apply_mentor_text", config.apply_mentor_text || defaultConfig.apply_mentor_text],
        ["mentor_website", config.mentor_website || defaultConfig.mentor_website],
        ["footer_mission", config.footer_mission || defaultConfig.footer_mission]
      ]);
    }

    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange,
        mapToCapabilities,
        mapToEditPanelValues
      });
    }
  </script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9a26501e57f09949',t:'MTc2Mzc5MjM0My4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>