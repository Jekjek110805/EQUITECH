<?php

function get_users(): array {
return [

'jakeengana' => password_hash('123456', PASSWORD_DEFAULT),
'jessamontebon' => password_hash('789', PASSWORD_DEFAULT),
'carencarpenters' => password_hash('12345', PASSWORD_DEFAULT),

];

}