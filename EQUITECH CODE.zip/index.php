<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EquiTech - Build Your Future</title>
  <script src="/_sdk/element_sdk.js"></script>
 <style>
   body {
    /* Ensures the background covers the entire viewport */
    min-height: 100vh;
    

    background-color: #150033;

    
}

    *, *::before, *::after {
      box-sizing: border-box;
    }

    html {
      height: 100%;
    }

    /* Header */
    header {
      background: #190f33;
      padding: 1.25rem 4rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgba(127, 90, 240, 0.15);
      position: sticky;
      top: 0;
      z-index: 1000;
      /* Ensure alignment with the centered hero content */
      max-width: 2600px; 
      margin: 0 auto;
    }

    .logo {
      font-size: 1.75rem;
      font-weight: 700;
      color: #ffffff;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    nav {
      display: flex;
      gap: 3rem;
      align-items: center;
    }

    nav a {
      color: #cccccc;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s;
      font-size: 1rem;
    }

    nav a:hover {
      color: #ffffff;
    }

    .auth-buttons {
      display: flex;
      gap: 1rem;
      align-items: center;
    }

    .login-btn {
      color: #ffffff;
      background: transparent;
      border: none;
      padding: 0.75rem 1.75rem;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      border-radius: 8px;
    }

    .login-btn:hover {
      background: rgba(127, 90, 240, 0.15);
    }

    .signup-btn {
      color: #ffffff;
      background: #7f5af0;
      border: none;
      padding: 0.75rem 1.75rem;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      border-radius: 8px;
    }

    .signup-btn:hover {
      background: #a466ff;
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(127, 90, 240, 0.4);
    }

    /* Hero Section */
    .hero {
      display: grid;
      /* Adjusted grid to give more width to the image (right column) for better balance */
      grid-template-columns: 0.7fr 1.3fr; 
      gap: 2rem; /* Reduced gap slightly */
      max-width: 2000px;
      margin: 0 auto;
      align-items: center;
      /* Ensure adequate height for the image */ 
      position: relative; /* Needed for reliable bottom alignment of image */
      padding-left:30px;  
    }

    .hero-left {
      display: flex;
      flex-direction: column;
      /* Increased gap between elements */
      gap: 1.5rem; 
    }

    .hero h1 {
      font-size: 2.5rem;
      font-weight: 800;
      line-height: 1.2;
      margin: 0;
      color: #ffffff;
    }

    .hero-highlight {
      color: #e6d644;
      display: inline;
    }

    .hero-description {
      font-size: 1.15rem;
      color: #cccccc;
      line-height: 1.8;
      margin: 0;
    }

    .hero-buttons {
      display: flex;
      gap: 1.5rem;
      margin-top: 1rem;
    }

    .hero-btn {
      padding: 1rem 2.5rem;
      border-radius: 8px;
      font-weight: 600;
      font-size: 1.05rem;
      cursor: pointer;
      transition: all 0.3s;
      border: none;
      white-space: nowrap;
      position: relative;
      overflow: hidden;
      text-decoration: none;
      display: inline-block;
      text-align: center;
    }

    .hero-btn::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.2);
      transform: translate(-50%, -50%);
      transition: width 0.6s, height 0.6s;
    }

    .hero-btn:hover::before {
      width: 300px;
      height: 300px;
    }

    .hero-btn span {
      position: relative;
      z-index: 1;
    }

    .hero-btn.primary {
      /* Matching background color */
      background: #2d1b5e; 
      color: #ffffff;
    }

    .hero-btn.primary:hover {
      background: #3d2575;
      transform: translateY(-3px);
      box-shadow: 0 10px 28px rgba(45, 27, 94, 0.6);
    }

    .hero-btn.secondary {
      background: transparent;
      /* Changed to the primary color for the border to match the visual */
      border: 2px solid #7f5af0; 
      color: #ffffff;
    }

    .hero-btn.secondary:hover {
      background: rgba(255, 255, 255, 0.1);
      transform: translateY(-3px);
      box-shadow: 0 10px 28px rgba(255, 255, 255, 0.2);
    }

    .hero-support {
      display: flex;
      flex-direction: column;
      /* Adjusted gap for better vertical spacing */
      gap: 1.5rem; 
      margin-top: 2.5rem; /* Add margin to separate from the main buttons */
    }

    .support-text {
      /* Removed unnecessary padding-top */
      padding-top:0px; 
      color: #cccccc;
      font-size: 0.95rem;
      font-weight: 500;
    }

 .social-icons {
        display: flex;
        gap: 1rem;
    }
    .social-icon {
          unicode-bidi: isolate;

        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: #2D1B4E;
        transition: all 0.3s ease;
        cursor: pointer;
    }
    .social-icon:hover {
        background: #A78BFA;
        transform: translateY(-3px);
    }
    .social-icon svg {
        color: #A78BFA;
    }

    /* Hero Right - Image Section (CRUCIAL FIX) */
    .hero-right {
      /* Removed min-width/min-height constraints for flexibility */
      align-items: center;
      justify-content: center;
      height: 10%;
      /* Added flex properties to ensure content (though empty) is aligned properly */
      display: flex; 
      
      background-image: url('Prof.png');
      /* Scales the background image to fit the container width, maintaining aspect ratio */
      background-size: contain; /* FIX: Changed to 'contain' for better fit */
      /* Centers the image horizontally and anchors it to the BOTTOM */
      background-position: center; 
      background-repeat: no-repeat; 
      /* Set a fixed height to ensure space for the image */
      min-height: 550px; 
      padding-top:300px; 
      margin-bottom: 320px; /* Ensures the image sits at the bottom of the section */
    }

    
    .professionals-group {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 2rem;
      position: relative;
      margin-bottom:30px;
    }

    .professional {
      align-items: center;
      gap: 1rem;
    }

    .laptop-icon {
      position: absolute;
      bottom: -20px;
      left: 50%;
      transform: translateX(-50%);
      width: 100px;
      height: 80px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2.5rem;
      backdrop-filter: blur(10px);
      border: 2px solid rgba(255, 255, 255, 0.2);
    }

    /* Statistics Section */
    .statistics {
      background: rgba(127, 90, 240, 0.08);
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 6rem;
      height: 220px;
      border-top: 1px solid rgba(127, 90, 240, 0.15);
      border-bottom: 1px solid rgba(127, 90, 240, 0.15);
    }

    .stat {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
      position: relative;
    }

    .stat:not(:last-child)::after {
      content: '';
      position: absolute;
      right: -3rem;
      top: 50%;
      transform: translateY(-50%);
      width: 1px;
      height: 60px;
      background: rgba(255, 255, 255, 0.15);
    }

    .stat-number {
      font-size: 3rem;
      font-weight: 800;
      color: #ffffff;
      margin: 0;
    }

    .stat-text {
      font-size: 1rem;
      color: #cccccc;
      text-align: center;
      margin: 0;
    }

    /* Footer */
    footer {
      text-align: center;
      padding: 2rem;
      color: #999999;
      font-size: 0.9rem;
      margin-top: 3rem;
    }

    /* Responsive */
    @media (max-width: 800px) {
      .hero {
        grid-template-columns: 1fr;
        gap: 3rem;
      }

      .hero-right {
        /* Puts the image below the text on small screens */
        order: 1; 
        min-height: 00px; 
        background-position: center bottom;
        background-size: 90% auto;
        margin-top:200px;
      }

      .statistics {
        flex-direction: column;
        gap: 3rem;
      }

      .stat:not(:last-child)::after {
        display: none;
      }
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        gap: 1.5rem;
      }

      nav {
        flex-wrap: wrap;
        justify-content: center;
        gap: 1.5rem;
      }

      .hero {
        
      }

      .hero h1 {
        font-size: 1.5rem;
      }

      .hero-description {
        font-size: 1rem;
      }

      .hero-buttons {
        flex-direction: column;
        gap: 1rem;
      }

      .hero-btn {
        width: 100%;
      }

      .stat-number {
        font-size: 2.5rem;
      }

      .statistics {
        padding: 3rem 2rem;
      }
    }

    /* Animations */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .hero-left > * {
      animation: fadeInUp 0.8s ease-out forwards;
    }

    .hero-left h1 {
      animation-delay: 0.1s;
    }

    .hero-left .hero-description {
      animation-delay: 0.3s;
    }

    .hero-left .hero-buttons {
      animation-delay: 0.5s;
    }

    .hero-left .hero-support {
      animation-delay: 0.7s;
    }
  </style>
  <style>@view-transition { navigation: auto; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
  <script src="https://cdn.tailwindcss.com" type="text/javascript"></script>
 </head>
 <body>
  <header>
    <div class="logo" id="site-name">
      EquiTech
    </div>
    <nav>
      <a href="aboutus.php">About us</a>
      <a href="E-learning.php">E-Learning</a>
      <a href="Training.php">Trainings</a>
      <a href="Findjob.php">Find Job</a>
      <a href="CV.php">CV Automation</a>
    </nav>
   <div class="auth-buttons">
    <a href="Loginpage.php" class="login-btn">Log in</a>
    <a href="Usersignup.php" class="signup-btn">Sign up</a>
</div>
  </header>
  <main>
    <section class="hero">
      <div class="hero-left">
        <h1>
          <span id="hero-title-part1">Build your future at EquiTech, where </span>
          <span class="hero-highlight" id="hero-title-highlight">equality</span>
          <span id="hero-title-part2"> is the foundation</span>
        </h1>
        <p class="hero-description" id="hero-description">
          Discover a job opportunities that offer fair pay, equitable growth, and a supportive environment. It's time to build a career on your own terms and find a place where you truly belong.
        </p>
        <div class="hero-buttons">
          <a href="Findjob.php" class="hero-btn primary">
            <span id="get-it-now-text">Get It Now</span>
          </a>
          <a href="E-Learning.php" class="hero-btn secondary">
            <span id="learn-more-text">Learn More →</span>
          </a>
        </div>
        <div class="hero-support">
          <p class="support-text" id="support-text">Supported by 5K+ Companies Worldwide</p>
          <div class="social-icons"> <div class="social-icon">
                  <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
            </div>
            <div class="social-icon">
              <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
              </svg>
            </div>
            <div class="social-icon">
              <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
              </svg>
            </div>
          </div> </div>
      </div>
      <div class="hero-right">
        <div class="hero-image-container">
          <div class="professionals-group">
            <div class="professional">
              <div class="professional-avatar">
          </div>
        </div>
      </div>
    </section>
    <section class="statistics">
      <div class="stat">
        <h2 class="stat-number" id="stat1-number">1,9K+</h2>
        <p class="stat-text" id="stat1-text">Ready Job Vacancy</p>
      </div>
      <div class="stat">
        <h2 class="stat-number" id="stat2-number">265K+</h2>
        <p class="stat-text" id="stat2-text">Job Seekers Active</p>
      </div>
      <div class="stat">
        <h2 class="stat-number" id="stat3-number">5,5K+</h2>
        <p class="stat-text" id="stat3-text">Incorporated Company</p>
      </div>
    </section>
  </main>
  <footer>
    <p id="copyright-text">All rights reserved 2025</p>
  </footer>
  <script>
    const defaultConfig = {
      site_name: "EquiTech",
      hero_title_part1: "Build your future at EquiTech, where ",
      hero_title_highlight: "equality",
      hero_title_part2: " is the foundation",
      hero_description: "Discover a job opportunities that offer fair pay, equitable growth, and a supportive environment. It's time to build a career on your own terms and find a place where you truly belong.",
      get_it_now_btn: "Get It Now",
      learn_more_btn: "Learn More →",
      support_text: "Supported by 5K+ Companies Worldwide",
      stat1_number: "1,9K+",
      stat1_text: "Ready Job Vacancy",
      stat2_number: "265K+",
      stat2_text: "Job Seekers Active",
      stat3_number: "5,5K+",
      stat3_text: "Incorporated Company",
      copyright_text: "All rights reserved 2025",
      background_color: "#190f33",
      surface_color: "rgba(127, 90, 240, 0.08)",
      text_color: "#ffffff",
      primary_action_color: "#7f5af0",
      highlight_color: "#e6d644",
      font_family: "sans-serif",
      font_size: 16
    };


    // Ripple effect on buttons
    document.querySelectorAll('.hero-btn, .signup-btn').forEach(btn => {
      btn.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        const rect = this.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;
        
        ripple.style.cssText = `
          position: absolute;
          width: ${size}px;
          height: ${size}px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.5);
          left: ${x}px;
          top: ${y}px;
          transform: scale(0);
          animation: ripple 0.6s ease-out;
          pointer-events: none;
        `;
        
        this.appendChild(ripple);
        
        setTimeout(() => {
          ripple.remove();
        }, 600);
      });
    });

    const style = document.createElement('style');
    style.textContent = `
      @keyframes ripple {
        to {
          transform: scale(4);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);

    // SDK Configuration
    async function onConfigChange(config) {
      const customFont = config.font_family || defaultConfig.font_family;
      const baseFontStack = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
      const fontFamily = `${customFont}, ${baseFontStack}`;
      const baseSize = config.font_size || defaultConfig.font_size;
      
      document.body.style.fontFamily = fontFamily;
      document.body.style.fontSize = `${baseSize}px`;
      document.body.style.background = config.background_color || defaultConfig.background_color;
      document.body.style.color = config.text_color || defaultConfig.text_color;

      // Update text content
      document.getElementById('site-name').textContent = config.site_name || defaultConfig.site_name;
      document.getElementById('hero-title-part1').textContent = config.hero_title_part1 || defaultConfig.hero_title_part1;
      document.getElementById('hero-title-highlight').textContent = config.hero_title_highlight || defaultConfig.hero_title_highlight;
      document.getElementById('hero-title-part2').textContent = config.hero_title_part2 || defaultConfig.hero_title_part2;
      document.getElementById('hero-description').textContent = config.hero_description || defaultConfig.hero_description;
      document.getElementById('get-it-now-text').textContent = config.get_it_now_btn || defaultConfig.get_it_now_btn;
      document.getElementById('learn-more-text').textContent = config.learn_more_btn || defaultConfig.learn_more_btn;
      document.getElementById('support-text').textContent = config.support_text || defaultConfig.support_text;
      document.getElementById('stat1-number').textContent = config.stat1_number || defaultConfig.stat1_number;
      document.getElementById('stat1-text').textContent = config.stat1_text || defaultConfig.stat1_text;
      document.getElementById('stat2-number').textContent = config.stat2_number || defaultConfig.stat2_number;
      document.getElementById('stat2-text').textContent = config.stat2_text || defaultConfig.stat2_text;
      document.getElementById('stat3-number').textContent = config.stat3_number || defaultConfig.stat3_number;
      document.getElementById('stat3-text').textContent = config.stat3_text || defaultConfig.stat3_text;
      document.getElementById('copyright-text').textContent = config.copyright_text || defaultConfig.copyright_text;

      // Update font sizes
      const heroTitle = document.querySelector('.hero h1');
      if (heroTitle) heroTitle.style.fontSize = `${baseSize * 3.5}px`;
      
      const heroDescription = document.querySelector('.hero-description');
      if (heroDescription) heroDescription.style.fontSize = `${baseSize * 1.15}px`;

      const statNumbers = document.querySelectorAll('.stat-number');
      statNumbers.forEach(num => num.style.fontSize = `${baseSize * 3}px`);
      
      // Update colors
      const heroHighlight = document.querySelector('.hero-highlight');
      if (heroHighlight) {
        heroHighlight.style.color = config.highlight_color || defaultConfig.highlight_color;
      }

      const signupBtn = document.querySelector('.signup-btn');
      if (signupBtn) {
        signupBtn.style.background = config.primary_action_color || defaultConfig.primary_action_color;
      }
    }

    function mapToCapabilities(config) {
      return {
        recolorables: [
          {
            get: () => config.background_color || defaultConfig.background_color,
            set: (value) => {
              config.background_color = value;
              window.elementSdk.setConfig({ background_color: value });
            }
          },
          {
            get: () => config.surface_color || defaultConfig.surface_color,
            set: (value) => {
              config.surface_color = value;
              window.elementSdk.setConfig({ surface_color: value });
            }
          },
          {
            get: () => config.text_color || defaultConfig.text_color,
            set: (value) => {
              config.text_color = value;
              window.elementSdk.setConfig({ text_color: value });
            }
          },
          {
            get: () => config.primary_action_color || defaultConfig.primary_action_color,
            set: (value) => {
              config.primary_action_color = value;
              window.elementSdk.setConfig({ primary_action_color: value });
            }
          },
          {
            get: () => config.highlight_color || defaultConfig.highlight_color,
            set: (value) => {
              config.highlight_color = value;
              window.elementSdk.setConfig({ highlight_color: value });
            }
          }
        ],
        borderables: [],
        fontEditable: {
          get: () => config.font_family || defaultConfig.font_family,
          set: (value) => {
            config.font_family = value;
            window.elementSdk.setConfig({ font_family: value });
          }
        },
        fontSizeable: {
          get: () => config.font_size || defaultConfig.font_size,
          set: (value) => {
            config.font_size = value;
            window.elementSdk.setConfig({ font_size: value });
          }
        }
      };
    }

    function mapToEditPanelValues(config) {
      return new Map([
        ["site_name", config.site_name || defaultConfig.site_name],
        ["hero_title_part1", config.hero_title_part1 || defaultConfig.hero_title_part1],
        ["hero_title_highlight", config.hero_title_highlight || defaultConfig.hero_title_highlight],
        ["hero_title_part2", config.hero_title_part2 || defaultConfig.hero_title_part2],
        ["hero_description", config.hero_description || defaultConfig.hero_description],
        ["get_it_now_btn", config.get_it_now_btn || defaultConfig.get_it_now_btn],
        ["learn_more_btn", config.learn_more_btn || defaultConfig.learn_more_btn],
        ["support_text", config.support_text || defaultConfig.support_text],
        ["stat1_number", config.stat1_number || defaultConfig.stat1_number],
        ["stat1_text", config.stat1_text || defaultConfig.stat1_text],
        ["stat2_number", config.stat2_number || defaultConfig.stat2_number],
        ["stat2_text", config.stat2_text || defaultConfig.stat2_text],
        ["stat3_number", config.stat3_number || defaultConfig.stat3_number],
        ["stat3_text", config.stat3_text || defaultConfig.stat3_text],
        ["copyright_text", config.copyright_text || defaultConfig.copyright_text]
      ]);
    }

    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange,
        mapToCapabilities,
        mapToEditPanelValues
      });
    }
  </script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9a265e8216b20986',t:'MTc2Mzc5MjkzMi4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>