<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EquiTech E-Learning Platform</title>
  <script src="/_sdk/element_sdk.js"></script>
  <style>
    /* Global Reset and Base Styles */
    body {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #150033;
      color: #ffffff;
      min-height: 100%;
    }
    * {
      box-sizing: border-box;
    }

    /* Layout Utility */
    .container {
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 2rem;
    }

    /* Scroll Container */
    .scroll-container {
      display: flex;
      gap: 1.5rem;
      overflow-x: auto;
      overflow-y: hidden;
      scroll-behavior: smooth;
      padding-bottom: 1rem;
      scrollbar-width: thin;
      scrollbar-color: #7C3AED #1A1A1A;
    }
    .scroll-container::-webkit-scrollbar {
      height: 8px;
    }
    .scroll-container::-webkit-scrollbar-track {
      background: #1A1A1A;
      border-radius: 4px;
    }
    .scroll-container::-webkit-scrollbar-thumb {
      background: #7C3AED;
      border-radius: 4px;
    }

    /* Header Styles */
    .header {
      background: linear-gradient(135deg, rgba(25, 15, 51, 0.98), rgba(43, 28, 75, 0.98));
      border-bottom: 1px solid #2D1B4E;
      padding: 1.5rem 0;
    }
    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .nav-group {
      display: flex;
      align-items: center;
      gap: 3rem;
    }
    .logo {
      font-size: 1.75rem;
      font-weight: 700;
      color: #ffffff;
    }
    .navbar {
      display: flex;
      gap: 2rem;
    }
    .subheader {
      margin-top: 2rem;
      margin-left:32rem;
      display: flex;
      align-items: center;
      gap: 1rem;
      text-align: center;

    }
    .subheader span {
      font-size: 1.5rem;
      font-weight: 700;
      color: #ffffff;
        text-align: center;

    }

    /* Navigation Links */
    .nav-link {
      position: relative;
      transition: color 0.3s ease;
      color: #D1D5DB;
      text-decoration: none;
      font-weight: 500;
    }
    .nav-link:hover {
      color: #ffffff;
    }
    .nav-link.active {
      color: #ffffff;
    }
    .nav-link.active::after {
      content: '';
      position: absolute;
      bottom: -8px;
      left: 0;
      right: 0;
      height: 2px;
      background: #7C3AED;
    }

    /* User Profile */
    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7C3AED 0%, #A78BFA 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
    }
    .user-info {
      display: flex;
      flex-direction: column;
      color:white;
    }
    .user-info span {
      font-weight: 600;
      font-size: 0.95rem;
    }
    .user-info a {
      color: #7C3AED;
      font-size: 0.8rem;
      text-decoration: none;
    }

    /* Main Content */
    main {
      max-width: 1400px;
      padding-top:2px;
      padding-left: 50px;
      padding-bottom: 50px;
      padding-right: 50px;

    }
    .section {
      margin-bottom: 10px;
      magi
    }
    .section-title {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 2rem;
      color: #ffffff;
    }

    /* Cards Base */
    .course-card {
      position: relative;
      border-radius: 1rem;
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      cursor: pointer;
    }
    .course-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 20px 40px rgba(124, 58, 237, 0.3);
    }
    .card-content {
      padding: 1.5rem;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .card-content h3 {
        font-size: 1.25rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        color: #ffffff;
    }
    .card-content p {
        font-size: 0.9rem;
        color: #D1D5DB;
    }
    .card-emoji {
        text-align: center;
        font-size: 3rem;
    }

    /* Category Card */
    .course-card-category {
      min-width: 280px;
      height: 320px;
      background: linear-gradient(135deg, #2D1B4E 0%, #1A1A1A 100%);
    }
    .course-card-category .card-content {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
    }
    .gradient-overlay {
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(21, 0, 51, 0) 0%, rgba(21, 0, 51, 0.95) 100%);
    }

    /* Recommended Card */
    .course-card-recommended {
      min-width: 320px;
      width: 100%;
      height: 240px;
      background: #1A1A1A;
      border: 1px solid #2D1B4E;
    }

    /* Recommended Card Text Colors */
    .text-green { color: #10B981; font-weight: 600; font-size: 1.1rem; }
    .text-yellow { color: #FCD34D; font-weight: 600; font-size: 1.1rem; }
    .text-red { color: #EF4444; font-weight: 700; font-size: 1.25rem; }

    /* Badge */
    .badge {
      background: rgba(124, 58, 237, 0.2);
      border: 1px solid #7C3AED;
      border-radius: 9999px;
      padding: 0.25rem 0.75rem;
      font-size: 0.75rem;
      font-weight: 600;
      color: #A78BFA;
      display: inline-block;
      margin-bottom: 1rem;
    }

    /* Footer Styles */
    .footer {
        background: #0D0021;
        border-top: 1px solid #2D1B4E;
        padding: 3rem 0 2rem;
    }
    .footer-grid {
        display: grid;
        grid-template-columns: 2fr 1fr 1fr 1fr;
        gap: 3rem;
        margin-bottom: 3rem;
    }
    .footer-logo {
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: #ffffff;
    }
    .footer-tagline {
        color: #9CA3AF;
        line-height: 1.6;
        margin-bottom: 1.5rem;
    }
    .social-icons {
        display: flex;
        gap: 1rem;
    }
    .social-icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: #2D1B4E;
        transition: all 0.3s ease;
        cursor: pointer;
    }
    .social-icon:hover {
        background: #A78BFA;
        transform: translateY(-3px);
    }
    .social-icon svg {
        color: #A78BFA;
    }
    .footer-nav h3 {
        color: #ffffff;
        font-weight: 700;
        font-size: 1.1rem;
        margin-bottom: 1rem;
    }
    .footer-nav ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    .footer-nav li {
        margin-bottom: 0.75rem;
    }
    .footer-nav a {
        color: #9CA3AF;
        text-decoration: none;
    }
    .copyright {
        border-top: 1px solid #2D1B4E;
        padding-top: 2rem;
        text-align: center;
        color: #6B7280;
        font-size: 0.9rem;
        margin: 0;
    }

     /* User Profile */
    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7C3AED 0%, #A78BFA 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
    }
    .user-info {
      display: flex;
      flex-direction: column;
      color:white;
    }
    .user-info span {
      font-weight: 600;
      font-size: 0.95rem;
    }
    .user-info a {
      color: #7C3AED;
      font-size: 0.8rem;
      text-decoration: none;
    }
    
  </style>
  <style>@view-transition { navigation: auto; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
 </head>
 <body>
  <header class="header">
   <div class="container">
    <div class="header-content">
     <div class="nav-group">
      <div class="logo"><span id="brand-name">EquiTech</span>
      </div>
      <nav class="navbar"><a href="aboutus.php" class="nav-link">About us</a> <a href="aboutus.php" class="nav-link active">E-Learning</a> <a href="Training.php" class="nav-link">Trainings</a> <a href="Findjob.php" class="nav-link">Find Job</a> <a href="CV.php" class="nav-link">CV Automation</a>
      </nav>
     </div>
    <div class="user-profile">
      <div class="user-avatar">
       RJ
      </div>
      <div class="user-info"><span id="user-name-display">RIEL JAKE E.</span> <a href="Userprofile.php">View profile</a>
      </div>
     </div>
    </div>
    <div class="subheader">
     <svg width="40" height="40" viewbox="0 0 40 40" fill="none"><path d="M20 5L30 12V28L20 35L10 28V12L20 5Z" fill="#3406b1ff" /> <path d="M20 15L25 18V26L20 29L15 26V18L20 15Z" fill="#A78BFA" />
    <center> </svg><span id="sub-brand-name-display">EquiCourse</span></center>
    </div>
   </div>
  </header>
  <main>
   <section class="section">
    <h2 class="section-title">Our Courses</h2>
    <div class="scroll-container">
     <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
     <div class="course-card course-card-category"><img src="https://i.pinimg.com/1200x/c9/8c/dc/c98cdc26499e1294391e124b473fa06d.jpg" style="width: 100%; height: 100%; object-fit: fill;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-2-name">Customer Service</h3>
       <p>199 Course, 1200+ Applied</p>
      </div>
     </div>
     <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/a7/a5/7f/a7a57f58a6f845dd23f017e1611d716f.jpg" style="width: 100%; height: 100%; object-fit: fill;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-3-name">AI Prompting</h3>
       <p>12 Course, 1500+ Applied</p>
      </div>
     </div>
     <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/b1/bb/ac/b1bbac1e29f08c1c7b5fa1cdb8d5aebb.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3>Networking</h3>
       <p>320 Course, 8000+ Applied</p>
      </div>
     </div>
     <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/0a/60/63/0a6063a878d4eeadf18d07b1e3cbc979.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3>Designing</h3>
       <p>420 Course, 5900+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/1200x/f9/2c/15/f92c15d097d2c8220d9b3a212ea8fd5c.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Cloud Computing</h3>
       <p>75 Course, 5000+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/97/42/bc/9742bc27e0673d8bcf508d0a54ec6b65.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Quality Assurance</h3>
       <p>63 Course, 3600+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/1200x/fe/e4/34/fee434f2350ebf10c51310f7621103a8.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">CyberSecurity</h3>
       <p>120 Course,17200+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/40/37/a4/4037a40aa42091a91b8d98f4450267fa.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Programming</h3>
       <p>30 Course, 30130+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/63/fe/5e/63fe5ed96f1287e2d3442b273239407a.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Ethical Hacking</h3>
       <p>11 Course, 125+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
      <div class="course-card course-card-category"><img src="https://i.pinimg.com/736x/6a/7a/15/6a7a150b675aeb0ed2b1995aa74ceb25.jpg" style="width: 100%; height: 100%; object-fit: cover;">
      <div class="gradient-overlay"></div>
      <div class="card-content">
       <h3 id="category-1-name">Digital Marketing</h3>
       <p>35 Course, 3000+ Applied</p>
      </div>
     </div>
    </div>
   </section>
   <section class="section">
    <h2 class="section-title">Recommended Courses For You</h2>
    <div class="scroll-container" style="margin-bottom: 1.5rem;">
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/cb/0a/df/cb0adf84670fa00d336f446498750c24.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">💰 MAKE MONEY</span>
        <h3>Earn $5000 a week</h3>
        <p class="text-green">Make Money With AI</p>
       </div>
       <div class="card-emoji">
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/a8/00/e9/a800e9f0a703072776d1f1184a48dbdd.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">⚡ QUICK JOB</span>
        <h3>CHATGPT!</h3>
        <p class="text-yellow">What A Real Quick Job!</p>
       </div>
       <div class="card-emoji">
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/4f/2a/19/4f2a19df762437691564d211117a321e.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">📱 SOCIAL MEDIA</span>
        <h3 class="text-red">Make 6 Digits Salary</h3>
        <p class="text-green">using Social Media</p>
       </div>
       <div class="card-emoji">
        💼
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/fc/15/59/fc1559b6db72329d7ee74a3e2e8a5be6.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">🚀 CAREER</span>
        <h3>Remote Work Mastery</h3>
        <p>Learn to work from anywhere</p>
       </div>
       <div class="card-emoji">
        🏠
       </div>
      </div>
     </div>
    </div>
    <div class="scroll-container" style="margin-bottom: 1.5rem;">
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/94/4f/9d/944f9dfc6b039beffc4957b8bec244aa.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">💼 GET A JOB</span>
        <h3>Get a Job now</h3>
        <p>Using these Websites</p>
       </div>
       <div class="card-emoji">
        💻
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/84/87/7f/84877f983b75f421b52874472beaf279.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">📺 CHANNEL</span>
        <h3>DREAM BIG</h3>
        <p>WORK HARD THEORY</p>
       </div>
       <div class="card-emoji">
        🎬
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/91/14/c6/9114c6e3ed7836d4a44a6e7b32050c77.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">🎯 FOCUS</span>
        <h3>Give purpose, stay focus</h3>
        <p>The Mastery of FOCUS</p>
       </div>
       <div class="card-emoji">
        🧠
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/3d/ad/00/3dad0007b09cc4382ff22912e3003e2e.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">📊 ANALYTICS</span>
        <h3>Data Science Basics</h3>
        <p>Start your analytics journey</p>
       </div>
       <div class="card-emoji">
        📈
       </div>
      </div>
     </div>
    </div>
    <div class="scroll-container" style="margin-bottom: 1.5rem;">
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/1200x/39/b6/97/39b697f16e94e1b899c30c6c0c2887a5.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">🎨 DESIGN</span>
        <h3>YOUTUBE THUMBNAIL</h3>
        <p class="text-green">SAVE 12% - 25%</p>
       </div>
       <div class="card-emoji">
        🖼️
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/60/50/f0/6050f03b7e6889d5f48c662cac72d842.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">🤖 AI</span>
        <h3>AI AUTOMATION</h3>
        <p>Learn Basic Automation</p>
       </div>
       <div class="card-emoji">
        ⚙️
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/d7/80/b4/d780b4f5fe26a7d0d503dcea46dec2bd.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">💎 BILLIONAIRE</span>
        <h3>SECRET TOOLS</h3>
        <p>Discover the tools to be a Billionaire</p>
       </div>
       <div class="card-emoji">
        💰
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/52/52/c1/5252c1d410d47604a63467db3091d2ce.jpg" style="width: 100%; height: 100%; object-fit: cover;">
       <div><span class="badge">🎓 LEARNING</span>
        <h3>Speed Reading</h3>
        <p>Read 3x faster</p>
       </div>
       <div class="card-emoji">
        📚
       </div>
      </div>
     </div>
    </div>
    <div class="scroll-container">
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/21/9a/a6/219aa60250130e28e133533258b2bd0b.jpg" style="width: 100%; height: 100%; object-fit: cover;"> 
       <div><span class="badge">⏰ PRODUCTIVITY</span>
        <h3>Working POMODORO</h3>
        <p>Technique</p>
       </div>
       <div class="card-emoji">
        🍅
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/89/dc/4a/89dc4ae8da9e79594474297eaf2e23fe.jpg" style="width: 100%; height: 100%; object-fit: cover;"> 
       <div><span class="badge">🎥 YOUTUBE</span>
        <h3>How to make money</h3>
        <p>using YouTube Studio</p>
       </div>
       <div class="card-emoji">
        📹
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/f5/36/25/f53625aaf68c89da40242f59972c0e55.jpg" style="width: 100%; height: 100%; object-fit: cover;"> 
       <div><span class="badge">☁️ CLOUD</span>
        <h3>Cloud Engineering</h3>
        <p>Roadmap - Tutorials</p>
       </div>
       <div class="card-emoji">
        🌩️
       </div>
      </div>
     </div>
     <div class="course-card course-card-recommended">
      <div class="card-content"><img src="https://i.pinimg.com/736x/4b/7d/0b/4b7d0b6f3045c2fe5875317658c0353a.jpg" style="width: 100%; height: 100%; object-fit: cover;"> 
       <div><span class="badge">💻 CODING</span>
        <h3>Full Stack Development</h3>
        <p>Complete web development</p>
       </div>
       <div class="card-emoji">
        ⌨️
       </div>
      </div>
     </div>
    </div>
   </section>
  </main>
  <footer class="footer">
   <div class="container">
    <div class="footer-grid">
     <div>
      <div class="footer-logo"><span id="footer-brand-name">EquiTech</span>
      </div>
      <p class="footer-tagline" id="footer-tagline-display">We have right mentors for any job. EquiTech will help you learn to code and help you to connect with them easily and effectively.</p>
      <div class="social-icons">
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zM12 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
       </div>
      </div>
     </div>
     <div class="footer-nav">
      <h3>Product</h3>
      <ul>
       <li><a href="#">Features</a></li>
       <li><a href="#">Pricing</a></li>
       <li><a href="#">Integrations</a></li>
       <li><a href="#">Changelog</a></li>
       <li><a href="#">Learnings</a></li>
      </ul>
     </div>
     <div class="footer-nav">
      <h3>Resources</h3>
      <ul>
       <li><a href="#">Documentation</a></li>
       <li><a href="#">Tutorials</a></li>
       <li><a href="#">Blogs</a></li>
       <li><a href="#">Support</a></li>
       <li><a href="#">FAQ</a></li>
      </ul>
     </div>
     <div class="footer-nav">
      <h3>Company</h3>
      <ul>
       <li><a href="#">About</a></li>
       <li><a href="#">Careers</a></li>
       <li><a href="#">Contact</a></li>
       <li><a href="#">Partners</a></li>
       <li><a href="#">Learnings</a></li>
      </ul>
     </div>
    </div>
    <p class="copyright">© 2022 EquiTech. All rights reserved.</p>
   </div>
  </footer>
  <script>
    const defaultConfig = {
      background_color: "#150033",
      surface_color: "#1A1A1A",
      text_color: "#ffffff",
      accent_color: "#7C3AED",
      secondary_accent_color: "#A78BFA",
      font_family: "Inter",
      font_size: 16,
      brand_name: "EquiTech",
      sub_brand_name: "EquiCourse",
      user_name: "RIEL JAKE E.",
      course_category_1: "Digital Marketing",
      course_category_2: "Customer Service",
      course_category_3: "AI Prompting",
      footer_tagline: "We have right mentors for any job. EquiTech will help you learn to code and help you to connect with them easily and effectively."
    };

    async function onConfigChange(config) {
      const customFont = config.font_family || defaultConfig.font_family;
      const baseFontStack = '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      const baseSize = config.font_size || defaultConfig.font_size;

      document.body.style.fontFamily = `${customFont}, ${baseFontStack}`;
      document.body.style.fontSize = `${baseSize}px`;
      document.body.style.background = config.background_color || defaultConfig.background_color;

      const headerElements = document.querySelectorAll('.header');
      headerElements.forEach(el => {
        el.style.background = config.background_color || defaultConfig.background_color;
      });

      const mainElement = document.querySelector('main');
      if (mainElement) {
        mainElement.style.color = config.text_color || defaultConfig.text_color;
      }

      const footerElement = document.querySelector('.footer');
      if (footerElement) {
        footerElement.style.background = '#0D0021';
      }

      const categoryCards = document.querySelectorAll('.course-card-category');
      categoryCards.forEach(card => {
        // NOTE: Keeping style manipulation here for dynamic config changes
        card.style.background = `linear-gradient(135deg, #2D1B4E 0%, ${config.surface_color || defaultConfig.surface_color} 100%)`;
      });

      const recommendedCards = document.querySelectorAll('.course-card-recommended');
      recommendedCards.forEach(card => {
        card.style.background = config.surface_color || defaultConfig.surface_color;
      });

      const navLinks = document.querySelectorAll('.nav-link');
      navLinks.forEach(link => {
        if (link.classList.contains('active')) {
          link.style.color = config.accent_color || defaultConfig.accent_color;
        }
      });

      const badges = document.querySelectorAll('.badge');
      badges.forEach(badge => {
        badge.style.background = `rgba(124, 58, 237, 0.2)`;
        badge.style.borderColor = config.accent_color || defaultConfig.accent_color;
        badge.style.color = config.secondary_accent_color || defaultConfig.secondary_accent_color;
      });

      const socialIcons = document.querySelectorAll('.social-icon');
      socialIcons.forEach(icon => {
        icon.style.background = '#2D1B4E';
      });

      const brandNameEl = document.getElementById('brand-name');
      if (brandNameEl) {
        brandNameEl.textContent = config.brand_name || defaultConfig.brand_name;
        brandNameEl.style.color = config.text_color || defaultConfig.text_color;
      }

      const subBrandNameEl = document.getElementById('sub-brand-name-display');
      if (subBrandNameEl) {
        subBrandNameEl.textContent = config.sub_brand_name || defaultConfig.sub_brand_name;
        subBrandNameEl.style.color = config.text_color || defaultConfig.text_color;
      }

      const userNameEl = document.getElementById('user-name-display');
      if (userNameEl) {
        userNameEl.textContent = config.user_name || defaultConfig.user_name;
      }

      const category1El = document.getElementById('category-1-name');
      if (category1El) {
        category1El.textContent = config.course_category_1 || defaultConfig.course_category_1;
        category1El.style.color = config.text_color || defaultConfig.text_color;
      }

      const category2El = document.getElementById('category-2-name');
      if (category2El) {
        category2El.textContent = config.course_category_2 || defaultConfig.course_category_2;
        category2El.style.color = config.text_color || defaultConfig.text_color;
      }

      const category3El = document.getElementById('category-3-name');
      if (category3El) {
        category3El.textContent = config.course_category_3 || defaultConfig.course_category_3;
        category3El.style.color = config.text_color || defaultConfig.text_color;
      }

      const footerBrandNameEl = document.getElementById('footer-brand-name');
      if (footerBrandNameEl) {
        footerBrandNameEl.textContent = config.brand_name || defaultConfig.brand_name;
        footerBrandNameEl.style.color = config.text_color || defaultConfig.text_color;
      }

      const footerTaglineEl = document.getElementById('footer-tagline-display');
      if (footerTaglineEl) {
        footerTaglineEl.textContent = config.footer_tagline || defaultConfig.footer_tagline;
      }

      const headings = document.querySelectorAll('.section-title');
      headings.forEach(h => {
        h.style.fontSize = `${baseSize * 2}px`;
        h.style.fontFamily = `${customFont}, ${baseFontStack}`;
        h.style.color = config.text_color || defaultConfig.text_color;
      });

      const h3Elements = document.querySelectorAll('.card-content h3');
      h3Elements.forEach(h => {
        h.style.fontSize = `${baseSize * 1.25}px`;
        h.style.fontFamily = `${customFont}, ${baseFontStack}`;
      });
    }

    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange,
        mapToCapabilities: (config) => ({
          recolorables: [
            {
              get: () => config.background_color || defaultConfig.background_color,
              set: (value) => {
                config.background_color = value;
                window.elementSdk.setConfig({ background_color: value });
              }
            },
            {
              get: () => config.surface_color || defaultConfig.surface_color,
              set: (value) => {
                config.surface_color = value;
                window.elementSdk.setConfig({ surface_color: value });
              }
            },
            {
              get: () => config.text_color || defaultConfig.text_color,
              set: (value) => {
                config.text_color = value;
                window.elementSdk.setConfig({ text_color: value });
              }
            },
            {
              get: () => config.accent_color || defaultConfig.accent_color,
              set: (value) => {
                config.accent_color = value;
                window.elementSdk.setConfig({ accent_color: value });
              }
            },
            {
              get: () => config.secondary_accent_color || defaultConfig.secondary_accent_color,
              set: (value) => {
                config.secondary_accent_color = value;
                window.elementSdk.setConfig({ secondary_accent_color: value });
              }
            }
          ],
          borderables: [],
          fontEditable: {
            get: () => config.font_family || defaultConfig.font_family,
            set: (value) => {
              config.font_family = value;
              window.elementSdk.setConfig({ font_family: value });
            }
          },
          fontSizeable: {
            get: () => config.font_size || defaultConfig.font_size,
            set: (value) => {
              config.font_size = value;
              window.elementSdk.setConfig({ font_size: value });
            }
          }
        }),
        mapToEditPanelValues: (config) => new Map([
          ["brand_name", config.brand_name || defaultConfig.brand_name],
          ["sub_brand_name", config.sub_brand_name || defaultConfig.sub_brand_name],
          ["user_name", config.user_name || defaultConfig.user_name],
          ["course_category_1", config.course_category_1 || defaultConfig.course_category_1],
          ["course_category_2", config.course_category_2 || defaultConfig.course_category_2],
          ["course_category_3", config.course_category_3 || defaultConfig.course_category_3],
          ["footer_tagline", config.footer_tagline || defaultConfig.footer_tagline]
        ])
      });
    }
  </script>
 </body>
</html>