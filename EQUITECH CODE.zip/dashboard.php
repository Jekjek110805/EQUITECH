<?php
// Protected page
session_start();
require_once __DIR__ . '/utils.php';

if (!isset($_SESSION['user'])) {
    // Try to authenticate from remember_me cookie
    if (!empty($_COOKIE['remember_me'])) {
        $cookie = $_COOKIE['remember_me'];
        $verified = verify_remember_cookie($cookie);
        if ($verified !== false) {
            // Verified: set session and rotate token
            $_SESSION['user'] = $verified;
            // rotate token: create new token and set cookie, delete old inside function
            $new = rotate_remember_token($cookie, $verified);
            if ($new !== false) {
                $options = get_cookie_options($new['expires']);
                setcookie('remember_me', $new['selector'] . ':' . $new['validator'], $options);
            }
        } else {
            // invalid cookie: remove
            clear_remember_cookie();
            header('Location: index.php');
            exit;
        }
    } else {
        header('Location: index.php');
        exit;
    }
}

$user = htmlspecialchars($_SESSION['user']);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <style>
    /* 1. Global Reset and Typography */
    :root {
      --primary-color: #007bff;
      --primary-dark: #0056b3;
      --background-light: #224dc2ff;
      --card-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      --border-radius: 8px;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
      background-color: var(--background-light);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
    }

    /* 2. Dashboard Box/Card Style */
    .dashboard-box {
      background: #ffffff;
      padding: 40px;
      border-radius: var(--border-radius);
      box-shadow: var(--card-shadow);
      width: 100%;
      max-width: 400px;
      text-align: center;
      transition: all 0.3s ease;
    }

    /* 3. Header Styling */
    h1 {
      color: #ffffffff;
      margin-top: 0;
      margin-bottom: 30px;
      font-size: 28px;
      font-weight: 600;
      line-height: 1.2;
    }

    /* 4. Link/Button Styling for Logout */
    .logout-link {
        display: inline-block;
        padding: 10px 20px;
        margin-top: 20px;
        background-color: var(--primary-color);
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        font-weight: 500;
        text-decoration: none;
        cursor: pointer;
        transition: background-color 0.3s, box-shadow 0.3s;
    }

    .logout-link:hover {
      background-color: var(--primary-dark);
      box-shadow: 0 4px 8px rgba(0, 123, 255, 0.3);
    }
  </style>
</head>
<body>
  <div clss="dashboard-box">
    <!-- Updated the greeting to use the larger H1 for impact -->
    <h1>Welcome, <?php echo $user; ?>!</h1>
    
    <!-- Styled the logout link to look like a button -->
    <p>You are successfully logged in.</p>
    <a href="logout.php" class="logout-link">Log out</a>
  </div>
</body>
</html>
