<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EquiTech - Remote Job Portal</title>
  <script src="/_sdk/element_sdk.js"></script>
  <style>
    body {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #190f33;
      color: #ffffff;
      min-height: 100%;
    }

    *, *::before, *::after {
      box-sizing: border-box;
    }

    html {
      height: 100%;
    }

    /* Header */
    header {
      background: rgba(25, 15, 51, 0.95);
      backdrop-filter: blur(10px);
      padding: 1rem 3rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgba(127, 90, 240, 0.2);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: #ffffffff;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    nav {
      display: flex;
      gap: 2.5rem;
      align-items: center;
    }

    nav a {
      color: #cccccc;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s;
      font-size: 0.95rem;
    }

    nav a:hover, nav a.active {
      color: #cccccc;
    }

     nav a.active {
      color: #ffffff;
      border-bottom: 2px solid rgba(127, 90, 240, 0.6);
    }

    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      background: rgba(127, 90, 240, 0.15);
      padding: 0.5rem 1rem;
      border-radius: 25px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .user-profile:hover {
      background: rgba(127, 90, 240, 0.25);
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7f5af0, #5236ad);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 0.85rem;
    }

    .user-info {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }

    .user-name {
      font-weight: 600;
      font-size: 0.9rem;
    }

    .view-profile {
      font-size: 0.75rem;
      color: #cccccc;
    }

    /* Hero Section */
    .hero {
      position: relative;
      padding: 4rem 3rem;
      background: linear-gradient(135deg, rgba(82, 54, 173, 0.4), rgba(127, 90, 240, 0.2)), 
                  url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 400"><rect fill="%23291552" width="1200" height="400"/><circle cx="200" cy="150" r="80" fill="%235236ad" opacity="0.3"/><circle cx="800" cy="250" r="100" fill="%237f5af0" opacity="0.2"/><circle cx="1000" cy="100" r="60" fill="%238fd749" opacity="0.2"/></svg>');
      background-size: cover;
      background-position: center;
      text-align: center;
    }

    .hero-content {
      max-width: 900px;
      margin: 0 auto;
    }

    .hero h1 {
      font-size: 4rem;
      font-weight: 800;
      margin: 0 0 1rem 0;
      background: linear-gradient(135deg, #ffffff, #7f5af0);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .hero-subtitle {
      font-size: 1.5rem;
      margin: 0 0 0.5rem 0;
      color: #ffffff;
      font-weight: 600;
    }

    .hero-description {
      font-size: 1.1rem;
      color: #cccccc;
      margin: 0 0 2.5rem 0;
      line-height: 1.6;
    }

    /* Search Bar */
    .search-container {
      background: rgba(255, 255, 255, 0.95);
      padding: 0.75rem;
      border-radius: 50px;
      display: flex;
      gap: 0.75rem;
      max-width: 700px;
      margin: 0 auto 2rem auto;
      box-shadow: 0 8px 32px rgba(127, 90, 240, 0.3);
    }

    .search-input {
      flex: 1;
      border: none;
      padding: 0.75rem 1.25rem;
      font-size: 0.95rem;
      outline: none;
      background: transparent;
      color: #190f33;
    }

    .search-input::placeholder {
      color: #666666;
    }

    .search-divider {
      width: 1px;
      background: #cccccc;
    }

    .search-button {
      background: #5236ad;
      color: white;
      border: none;
      padding: 0.75rem 2rem;
      border-radius: 50px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      font-size: 0.95rem;
    }

    .search-button:hover {
      background: #7f5af0;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(127, 90, 240, 0.4);
    }

    /* Category Pills */
    .categories {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
      max-width: 900px;
      margin: 0 auto;
    }

    .category-pill {
      padding: 0.65rem 1.5rem;
      border-radius: 25px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      font-size: 0.9rem;
      border: 2px solid transparent;
    }

    .category-pill:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }

    .category-pill.active {
      border-color: rgba(255, 255, 255, 0.3);
    }

    .category-pill.design {
      background: #8fd749;
      color: #190f33;
    }

    .category-pill.developer {
      background: #40b7d7;
      color: #190f33;
    }

    .category-pill.hr {
      background: #ffb833;
      color: #190f33;
    }

    .category-pill.service {
      background: #a0d348;
      color: #190f33;
    }

    .category-pill.marketing {
      background: #6236ad;
      color: #ffffff;
    }

    .category-pill.data {
      background: #6236ad;
      color: #ffffff;
    }

    .category-pill.devops {
      background: #d9534f;
      color: #ffffff;
    }

    .category-pill.engineering {
      background: #40b7d7;
      color: #190f33;
    }

    /* Jobs Section */
    .jobs-section {
      padding: 4rem 3rem;
      max-width: 1400px;
      margin: 0 auto;
    }

    .jobs-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1.5rem;
    }

    .job-card {
      background: rgba(41, 21, 82, 0.6);
      border: 1px solid rgba(127, 90, 240, 0.2);
      border-radius: 16px;
      padding: 1.75rem;
      cursor: pointer;
      transition: all 0.3s;
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .job-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 24px rgba(127, 90, 240, 0.3);
      border-color: rgba(127, 90, 240, 0.5);
    }

    .job-header {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

   .company-logo {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: linear-gradient(135deg, #fafafaff, #ffffffff);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 1.2rem;
  color: white;
  flex-shrink: 0;
}

/* ... in your <style> block ... */
.company-logo {
  /* ... (existing styles) ... */
  overflow: hidden; /* Important to clip the image to the border-radius */
}

.company-logo img {
  width: 100%;
  height: 100%;
  object-fit: cover; /* Ensures the image covers the container without distortion */
  border-radius: 12px; /* Ensure image also gets the border radius if it fills the container */
}
/* ... rest of your styles ... */

    .job-title-wrapper {
      flex: 1;
    }

    .job-title {
      font-size: 1.1rem;
      font-weight: 700;
      margin: 0 0 0.25rem 0;
      color: #ffffff;
    }

    .company-name {
      font-size: 0.9rem;
      color: #cccccc;
    }

    .job-category {
      display: inline-block;
      padding: 0.4rem 1rem;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 600;
    }

    .job-location {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: #cccccc;
      font-size: 0.9rem;
    }

    .job-time {
      color: #999999;
      font-size: 0.85rem;
      margin-bottom: 0.5rem; /* Added margin for separation before actions */
    }

    /* --- NEW STYLES FOR BUTTONS --- */
    .job-actions {
      display: flex;
      gap: 0.75rem;
      margin-top: auto; /* Pushes the actions block to the bottom of the flex container (job-card) */
      padding-top: 1rem;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    .job-button {
      padding: 0.75rem 1.25rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      font-size: 0.9rem;
      border: none;
    }

    .apply-button {
      flex-grow: 1;
      background: #7f5af0; /* Using the secondary/accent color */
      color: #ffffff;
    }

    .apply-button:hover {
      background: #5236ad; /* Darker shade on hover */
    }

    .add-to-button {
      background: rgba(255, 255, 255, 0.1);
      color: #ffffff;
      width: 40px; /* Fixed width for a small icon button */
      padding: 0.75rem 0.5rem;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    .add-to-button:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    /* --- END NEW STYLES --- */

    /* Responsive */
    @media (max-width: 1024px) {
      header {
        padding: 1rem 2rem;
      }

      .hero {
        padding: 3rem 2rem;
      }

      .hero h1 {
        font-size: 3rem;
      }

      .jobs-section {
        padding: 3rem 2rem;
      }

      nav {
        gap: 1.5rem;
      }
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        gap: 1rem;
        padding: 1rem;
      }

      nav {
        flex-wrap: wrap;
        justify-content: center;
        gap: 1rem;
      }

      .hero h1 {
        font-size: 2.5rem;
      }

      .hero-subtitle {
        font-size: 1.2rem;
      }

      .search-container {
        flex-direction: column;
        gap: 0.5rem;
        border-radius: 16px;
      }

      .search-divider {
        display: none;
      }

      .search-button {
        width: 100%;
      }

      .jobs-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
  <style>@view-transition { navigation: auto; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
  <script src="https://cdn.tailwindcss.com" type="text/javascript"></script>
 </head>
<body>
  <header>
    <div class="logo" id="site-name">
     EquiTech
    </div>
    <nav>
      <a href="aboutus.php">About us</a>
      <a href="E-Learning.php">E-Learning</a>
      <a href="Training.php">Trainings</a>
      <a href="Findjob.php" class="active">Find Job</a>
      <a href="CV.php">CV Automation</a>
    </nav>
    <div class="user-profile">
      <div class="user-avatar">
        H
      </div>
      <div class="user-info">
        <div class="user-name" id="user-name">
          RIEL JAKE E.
        </div>
        <div class="view-profile">
          View profile
        </div>
      </div>
    </div>
  </header>
  <main>
    <section class="hero">
      <div class="hero-content">
        <h1 id="hero-title"> Work Remotely</h1>
        <div class="hero-subtitle" id="hero-subtitle">
          Welcome! Discover a job
        </div>
        <p class="hero-description" id="hero-description">that offer fair pay, equitable growth, and a supportive environment</p>
        <div class="search-container">
          <input type="text" class="search-input" id="search-job" placeholder="Job title or keyword">
          <div class="search-divider"></div>
          <input type="text" class="search-input" id="search-location" placeholder="Anywhere">
          <button class="search-button" id="search-btn">Search now</button>
        </div>
        <div class="categories">
          <div class="category-pill design active" data-category="all">
            Design (23,521)
          </div>
          <div class="category-pill developer" data-category="developer">
            Developer (17,211)
          </div>
          <div class="category-pill hr" data-category="hr">
            HR (11,801)
          </div>
          <div class="category-pill service" data-category="service">
            Customer Service (85,561)
          </div>
          <div class="category-pill marketing" data-category="marketing">
            Marketing (22,111)
          </div>
        </div>
      </div>
    </section>
    <section class="jobs-section">
      <div class="jobs-grid" id="jobs-grid">
        </div>
    </section>
  </main>
  <footer style="background: #0D0021; border-top: 1px solid #2D1B4E; padding: 3rem 0 2rem;">
   <div style="max-width: 1400px; margin: 0 auto; padding: 0 2rem;">
    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 3rem; margin-bottom: 3rem;"><!-- Company Info -->
     <div>
      <div style="font-size: 1.75rem; font-weight: 700; margin-bottom: 1rem;"><span style="color: #ffffff;" id="footer-brand-name">EquiTech</span>
      </div>
      <p style="color: #9CA3AF; line-height: 1.6; margin-bottom: 1.5rem;" id="footer-tagline-display">We have right mentors for any job. EquiTech will help you learn to code and help you to connect with them easily and effectively.</p><!-- Social Icons -->
      <div style="display: flex; gap: 1rem;">
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
        </svg>
       </div>
       <div class="social-icon">
        <svg width="20" height="20" viewbox="0 0 24 24" fill="currentColor" style="color: #A78BFA;"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
       </div>
      </div>
     </div><!-- Product -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Product</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Features</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Pricing</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Integrations</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Changelog</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div><!-- Resources -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Resources</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Documentation</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Tutorials</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Blogs</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Support</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">FAQ</a></li>
      </ul>
     </div><!-- Company -->
     <div>
      <h3 style="color: #ffffff; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">Company</h3>
      <ul style="list-style: none; padding: 0; margin: 0;">
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">About</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Careers</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Contact</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Partners</a></li>
       <li style="margin-bottom: 0.75rem;"><a href="#" style="color: #9CA3AF; text-decoration: none;">Learnings</a></li>
      </ul>
     </div>
    </div><!-- Copyright -->
    <div style="border-top: 1px solid #2D1B4E; padding-top: 2rem; text-align: center;">
     <p style="color: #6B7280; font-size: 0.9rem; margin: 0;">© 2022 EquiTech. All rights reserved.</p>
    </div>
   </div>
  </footer>
  <script>
    const defaultConfig = {
      site_name: "直 EquiTech",
      user_name: "Hiccup H.",
      hero_title: "Remotely",
      hero_subtitle: "Welcome! Discover a job",
      hero_description: "that offer fair pay, equitable growth, and a supportive environment",
      search_placeholder_1: "Job title or keyword",
      search_placeholder_2: "Anywhere",
      search_button: "Search now",
      background_color: "#190f33",
      surface_color: "rgba(41, 21, 82, 0.6)",
      text_color: "#ffffff",
      primary_action_color: "#5236ad",
      secondary_action_color: "#7f5af0",
      font_family: "sans-serif",
      font_size: 16
    };

   // Job data
const jobs = [
  { title: "Senior Product Designer", company: "Google", category: "Design", location: "Philippines, Cebu, IT Park", time: "3 days ago", logo: 'G', logo_src: "https://www.gstatic.com/marketing-cms/assets/images/d5/dc/cfe9ce8b4425b410b49b7f2dd3f3/g.webp=s48-fcrop64=1,00000000ffffffff-rw" },
  { title: "Senior Web Developer", company: "Accenture", category: "Development", location: "Cebu- It Park - Philippines", time: "5 days ago", logo: "A", logo_src: "https://proximosdividendos.info/en/wp-content/uploads/Accenture_logo.webp" },
  { title: "Junior Database Manager", company: "Kyocera", category: "Data Analyst", location: "Konoha, Japan", time: "7 days ago", logo: "K", logo_src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRrA2_jLNWKGPEmy29F-niHe2P52reToWyMENKrJtwAsybym-tudthmdDTSc8wo-BjIMM&usqp=CAU"}, // No image, will use 'K'
  { title: "Customer Service", company: "Synchrony", category: "Service", location: "Philippines, Cebu, IT Park", time: "3 days ago", logo: "S", logo_src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRe1CnYuIkmCnwAYdZ6nGQ4wbWBBQYUby_2QyR2XDuDFFtfb6pFhJceqbhk7syrIW8QtjA&usqp=CAU" }, // No image, will use 'S'
  { title: "Senior Website Developer", company: "Alliance", category: "Development", location: "Demlu, Jakarta - Indonesia", time: "10 days ago", logo: "A", logo_src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_69z9V_-PxWojKdT7TfSQtG48iOwfOuVWKw&s" },
  { title: "Senior Database Manager", company: "J.P. Morgan", category: "Data Analyst", location: "Konoha, Japan", time: "15 days ago", logo: "JP", logo_src: "https://www.pillar.vc/playlist/wp-content/uploads/sites/3/2020/09/unnamed-1.jpg" },
  { title: "Senior Product Designer", company: "Datawords", category: "Design", location: "Philippines, Cebu, IT Park", time: "5 days ago", logo: "D", logo_src: "https://d1zx4fn8ox8446.cloudfront.net/filemanager.rboxfile/5b7dca331afb4545a0ba363f35b48c93/Datawords_AppLogo.jpg" },
  { title: "Quality Assurance", company: "Viseo", category: "Development", location: "Demlu, Jakarta - Indonesia", time: "20 days ago", logo: "V", logo_src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTddlAtVQerjwmnbR7wVqGdU3uM6_Fi26Kj8A&s" },
  { title: "Junior Database Manager", company: "Amazon", category: "Data Analyst", location: "Konoha, Japan", time: "38 days ago", logo: "A", logo_src: "https://www.freeiconspng.com/thumbs/amazon-icon/amazon-icon--socialmedia-iconset--uiconstock-0.png" },
  { title: "Development Operator", company: "ChinaBank", category: "DevOps", location: "Philippines, Cebu, IT Park", time: "12 days ago", logo: "CB", logo_src: "https://pana.com.ph/wp-content/uploads/chinabank.jpg" },
  { title: "Cybersecurity Engineer", company: "BDO", category: "Engineering", location: "Demlu, Jakarta - Indonesia", time: "8 days ago", logo: "B", logo_src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8IwvIFb0qtFiotKfgtgCuTeVEvumlnu7oNQ&s" },
  { title: "Mobile App Tester", company: "TrueArc", category: "Developer", location: "Konoha, Japan", time: "6 days ago", logo: "T", logo_src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNrf8Jlvhf0yXImEtiHI8Nov3Vr7mpIvTRxWSBcXJcX2miDtJnp0KMi2vfH2xYezJOqjE&usqp=CAU" }
];

    let filteredJobs = [...jobs];

    function getCategoryClass(category) {
      const map = {
        "Design": "design",
        "Development": "developer",
        "Developer": "developer",
        "Data Analyst": "data",
        "Service": "service",
        "DevOps": "devops",
        "Engineering": "engineering"
      };
      return map[category] || "developer";
    }

   // Function to render job cards - MODIFIED to include buttons AND logo image
function renderJobs() {
  const grid = document.getElementById('jobs-grid');
  grid.innerHTML = '';
  
  filteredJobs.forEach(job => {
    // Determine the content of the logo container (Image or Text Initial)
    const logoContent = job.logo_src 
      ? `<img src="${job.logo_src}" alt="${job.company} logo">` 
      : job.logo;

    const card = document.createElement('div');
    card.className = 'job-card';
    card.innerHTML = `
      <div class="job-header">
        <div class="company-logo">${logoContent}</div>
        <div class="job-title-wrapper">
          <h3 class="job-title">${job.title}</h3>
          <div class="company-name">${job.company}</div>
        </div>
      </div>
      <div class="job-category ${getCategoryClass(job.category)}">${job.category}</div>
      <div class="job-location">桃 ${job.location}</div>
      <div class="job-time">葡 ${job.time}</div>
      <div class="job-actions">
        <button class="job-button apply-button">APPLY NOW</button>
        <button class="job-button add-to-button">💖</button>
      </div>
    `;
    grid.appendChild(card);
  });
}

    // Category filtering
    document.querySelectorAll('.category-pill').forEach(pill => {
      pill.addEventListener('click', function() {
        document.querySelectorAll('.category-pill').forEach(p => p.classList.remove('active'));
        this.classList.add('active');
        
        const category = this.getAttribute('data-category');
        if (category === 'all') {
          filteredJobs = [...jobs];
        } else {
          filteredJobs = jobs.filter(job => {
            const jobCat = job.category.toLowerCase();
            return jobCat.includes(category) || category.includes(jobCat);
          });
        }
        renderJobs();
      });
    });

    // Search functionality
    document.getElementById('search-btn').addEventListener('click', function() {
      const jobQuery = document.getElementById('search-job').value.toLowerCase();
      const locationQuery = document.getElementById('search-location').value.toLowerCase();
      
      filteredJobs = jobs.filter(job => {
        const matchesJob = !jobQuery || 
          job.title.toLowerCase().includes(jobQuery) || 
          job.company.toLowerCase().includes(jobQuery) ||
          job.category.toLowerCase().includes(jobQuery);
        
        const matchesLocation = !locationQuery || 
          job.location.toLowerCase().includes(locationQuery);
        
        return matchesJob && matchesLocation;
      });
      
      renderJobs();
    });

    async function onConfigChange(config) {
      const customFont = config.font_family || defaultConfig.font_family;
      const baseFontStack = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
      const fontFamily = `${customFont}, ${baseFontStack}`;
      const baseSize = config.font_size || defaultConfig.font_size;
      
      document.body.style.fontFamily = fontFamily;
      document.body.style.fontSize = `${baseSize}px`;
      document.body.style.background = config.background_color || defaultConfig.background_color;
      document.body.style.color = config.text_color || defaultConfig.text_color;

      const jobCards = document.querySelectorAll('.job-card');
      jobCards.forEach(card => {
        card.style.background = config.surface_color || defaultConfig.surface_color;
      });

      const buttons = document.querySelectorAll('.search-button');
      buttons.forEach(btn => {
        btn.style.background = config.primary_action_color || defaultConfig.primary_action_color;
      });

      const logo = document.querySelector('.logo');
      if (logo) logo.style.color = config.secondary_action_color || defaultConfig.secondary_action_color;

      document.getElementById('site-name').textContent = config.site_name || defaultConfig.site_name;
      document.getElementById('user-name').textContent = config.user_name || defaultConfig.user_name;
      document.getElementById('hero-title').textContent = config.hero_title || defaultConfig.hero_title;
      document.getElementById('hero-subtitle').textContent = config.hero_subtitle || defaultConfig.hero_subtitle;
      document.getElementById('hero-description').textContent = config.hero_description || defaultConfig.hero_description;
      document.getElementById('search-job').placeholder = config.search_placeholder_1 || defaultConfig.search_placeholder_1;
      document.getElementById('search-location').placeholder = config.search_placeholder_2 || defaultConfig.search_placeholder_2;
      document.getElementById('search-btn').textContent = config.search_button || defaultConfig.search_button;

      const heroTitle = document.querySelector('.hero h1');
      if (heroTitle) heroTitle.style.fontSize = `${baseSize * 4}px`;
      
      const heroSubtitle = document.querySelector('.hero-subtitle');
      if (heroSubtitle) heroSubtitle.style.fontSize = `${baseSize * 1.5}px`;
    }

    function mapToCapabilities(config) {
      return {
        recolorables: [
          {
            get: () => config.background_color || defaultConfig.background_color,
            set: (value) => {
              config.background_color = value;
              window.elementSdk.setConfig({ background_color: value });
            }
          },
          {
            get: () => config.surface_color || defaultConfig.surface_color,
            set: (value) => {
              config.surface_color = value;
              window.elementSdk.setConfig({ surface_color: value });
            }
          },
          {
            get: () => config.text_color || defaultConfig.text_color,
            set: (value) => {
              config.text_color = value;
              window.elementSdk.setConfig({ text_color: value });
            }
          },
          {
            get: () => config.primary_action_color || defaultConfig.primary_action_color,
            set: (value) => {
              config.primary_action_color = value;
              window.elementSdk.setConfig({ primary_action_color: value });
            }
          },
          {
            get: () => config.secondary_action_color || defaultConfig.secondary_action_color,
            set: (value) => {
              config.secondary_action_color = value;
              window.elementSdk.setConfig({ secondary_action_color: value });
            }
          }
        ],
        borderables: [],
        fontEditable: {
          get: () => config.font_family || defaultConfig.font_family,
          set: (value) => {
            config.font_family = value;
            window.elementSdk.setConfig({ font_family: value });
          }
        },
        fontSizeable: {
          get: () => config.font_size || defaultConfig.font_size,
          set: (value) => {
            config.font_size = value;
            window.elementSdk.setConfig({ font_size: value });
          }
        }
      };
    }

    function mapToEditPanelValues(config) {
      return new Map([
        ["site_name", config.site_name || defaultConfig.site_name],
        ["user_name", config.user_name || defaultConfig.user_name],
        ["hero_title", config.hero_title || defaultConfig.hero_title],
        ["hero_subtitle", config.hero_subtitle || defaultConfig.hero_subtitle],
        ["hero_description", config.hero_description || defaultConfig.hero_description],
        ["search_placeholder_1", config.search_placeholder_1 || defaultConfig.search_placeholder_1],
        ["search_placeholder_2", config.search_placeholder_2 || defaultConfig.search_placeholder_2],
        ["search_button", config.search_button || defaultConfig.search_button]
      ]);
    }

    // Initialize
    renderJobs();   

    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange,
        mapToCapabilities,
        mapToEditPanelValues
      });
    }
  </script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9a261a6d401c0986',t:'MTc2Mzc5MDE0My4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>