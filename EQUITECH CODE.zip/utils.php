<?php
// Utilities for remember-me token handling using selector:validator and a simple tokens.json store.
// Requires PHP 7.3+ for setcookie options array. For local HTTP testing, setSecure will be false.

define('TOKENS_FILE', __DIR__ . '/tokens.json');

// Helper: return true if current request uses HTTPS
function is_request_https(): bool {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') return true;
    return false;
}

// Cookie options
function get_cookie_options(int $expires): array {
    // If you're testing on localhost without HTTPS, change secure to false.
    $secure = is_request_https();
    return [
        'expires'  => $expires,
        'path'     => '/',
        'domain'   => '',        // set to your domain if needed, e.g. 'example.com'
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',     // 'Lax' is a sensible default
    ];
}

// Ensure tokens file exists
function ensure_tokens_file(): void {
    if (!file_exists(TOKENS_FILE)) {
        file_put_contents(TOKENS_FILE, json_encode([], JSON_PRETTY_PRINT));
    }
}

// Load tokens (associative array: selector => [validator_hash, username, expires])
function load_tokens(): array {
    ensure_tokens_file();
    $json = file_get_contents(TOKENS_FILE);
    $arr = json_decode($json, true);
    return is_array($arr) ? $arr : [];
}

function save_tokens(array $tokens): void {
    // Use locking
    $tmp = tempnam(sys_get_temp_dir(), 'tkn');
    file_put_contents($tmp, json_encode($tokens, JSON_PRETTY_PRINT));
    rename($tmp, TOKENS_FILE);
}

// Create and store a remember token for $username
function create_remember_token(string $username): array {
    $selector = bin2hex(random_bytes(9)); // shorter identifier
    $validator = bin2hex(random_bytes(33)); // kept secret in cookie
    $validator_hash = hash('sha256', $validator);
    $expires = time() + 60 * 60 * 24 * 30; // 30 days

    $tokens = load_tokens();
    $tokens[$selector] = [
        'validator_hash' => $validator_hash,
        'username' => $username,
        'expires' => $expires
    ];
    save_tokens($tokens);

    return ['selector' => $selector, 'validator' => $validator, 'expires' => $expires];
}

// Verify cookie value "selector:validator". Returns username on success, false on failure.
function verify_remember_cookie(string $cookie) {
    $parts = explode(':', $cookie, 2);
    if (count($parts) !== 2) return false;
    [$selector, $validator] = $parts;
    $tokens = load_tokens();
    if (empty($tokens[$selector])) return false;
    $record = $tokens[$selector];
    if ($record['expires'] < time()) {
        // expired: remove
        unset($tokens[$selector]);
        save_tokens($tokens);
        return false;
    }
    $hash = hash('sha256', $validator);
    if (!hash_equals($record['validator_hash'], $hash)) {
        // possible theft: remove all tokens for this user (optional)
        remove_tokens_for_user($record['username']);
        return false;
    }
    return $record['username'];
}

// Rotate token: delete old selector and create a fresh one. Returns new token array or false.
function rotate_remember_token(string $oldCookie, string $username) {
    $parts = explode(':', $oldCookie, 2);
    if (count($parts) !== 2) return false;
    $oldSelector = $parts[0];
    $tokens = load_tokens();
    if (isset($tokens[$oldSelector])) {
        unset($tokens[$oldSelector]);
        save_tokens($tokens);
    }
    return create_remember_token($username);
}

// Remove tokens for a given user
function remove_tokens_for_user(string $username): void {
    $tokens = load_tokens();
    foreach ($tokens as $selector => $rec) {
        if ($rec['username'] === $username) {
            unset($tokens[$selector]);
        }
    }
    save_tokens($tokens);
}

// Clear cookie and delete token server-side if possible
function clear_remember_cookie(): void {
    if (empty($_COOKIE['remember_me'])) return;
    $cookie = $_COOKIE['remember_me'];
    $parts = explode(':', $cookie, 2);
    if (count($parts) === 2) {
        $selector = $parts[0];
        $tokens = load_tokens();
        if (isset($tokens[$selector])) {
            unset($tokens[$selector]);
            save_tokens($tokens);
        }
    }
    // Clear cookie in browser
    $options = get_cookie_options(time() - 3600);
    setcookie('remember_me', '', $options);
}